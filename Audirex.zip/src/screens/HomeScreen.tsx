import React from 'react';
import {
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

type HomeScreenProps = {
  onSearchPress: () => void;
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

const HomeScreen = ({
  onSearchPress,
  onMenuPress,
  onPlayerPress,
}: HomeScreenProps) => {

  const getGreeting = () => {
    const hour = new Date().getHours();

    if (hour < 12) {
      return 'Good morning';
    }

    if (hour < 18) {
      return 'Good afternoon';
    }

    return 'Good evening';
  };

  return (
    <View style={styles.container}>

      {/* HEADER */}

      <View style={styles.header}>

        <TouchableOpacity
          style={styles.menuButton}
          activeOpacity={0.7}
          onPress={onMenuPress}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </TouchableOpacity>

        <View style={styles.headerText}>

          <Text style={styles.greeting}>
            {getGreeting()}
          </Text>

          <Text style={styles.subtitle}>
            Music makes everything better.
          </Text>

        </View>

      </View>


      {/* CONTENT */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>

        {/* SEARCH */}

        <TouchableOpacity
          style={styles.searchBar}
          activeOpacity={0.8}
          onPress={onSearchPress}>

          <Text style={styles.searchIcon}>
            ⌕
          </Text>

          <Text style={styles.searchPlaceholder}>
            Search songs, artists, albums...
          </Text>

          <Text style={styles.micIcon}>
            ♪
          </Text>

        </TouchableOpacity>


        {/* HERO */}

        <View style={styles.heroCard}>

          <View style={styles.heroText}>

            <Text style={styles.heroEyebrow}>
              YOUR DAILY SOUNDTRACK
            </Text>

            <Text style={styles.heroTitle}>
              Today's Vibes
            </Text>

            <Text style={styles.heroSubtitle}>
              Curated just for you
            </Text>

          </View>


          <View style={styles.heroArtwork}>

            <View style={styles.heroArtworkRing} />

            <View style={styles.heroArtworkBottom} />

          </View>


          <TouchableOpacity
            style={styles.playButton}
            activeOpacity={0.8}>

            <Text style={styles.playIcon}>
              ▶
            </Text>

          </TouchableOpacity>

        </View>


        {/* RECENTLY PLAYED */}

        <View style={styles.sectionHeader}>

          <Text style={styles.sectionTitle}>
            Recently Played
          </Text>

          <TouchableOpacity>
            <Text style={styles.seeAll}>
              See all
            </Text>
          </TouchableOpacity>

        </View>


        <View style={styles.recentRow}>

          <View style={styles.recentItem}>

            <View style={styles.albumPlaceholder}>
              <View style={styles.albumRing} />
            </View>

            <Text style={styles.songTitle}>
              Starlight
            </Text>

            <Text style={styles.artistName}>
              The Weeknd
            </Text>

          </View>


          <View style={styles.recentItem}>

            <View style={styles.albumPlaceholder}>
              <View style={styles.albumRing} />
            </View>

            <Text style={styles.songTitle}>
              Cruel Summer
            </Text>

            <Text style={styles.artistName}>
              Taylor Swift
            </Text>

          </View>


          <View style={styles.recentItem}>

            <View style={styles.albumPlaceholder}>
              <View style={styles.albumRing} />
            </View>

            <Text style={styles.songTitle}>
              As It Was
            </Text>

            <Text style={styles.artistName}>
              Harry Styles
            </Text>

          </View>

        </View>


        {/* MADE FOR YOU */}

        <View style={styles.sectionHeader}>

          <Text style={styles.sectionTitle}>
            Made For You
          </Text>

          <TouchableOpacity>
            <Text style={styles.seeAll}>
              Explore
            </Text>
          </TouchableOpacity>

        </View>


        <View style={styles.mixGrid}>

          <TouchableOpacity style={styles.mixCard}>
            <View style={styles.mixArtwork} />

            <Text style={styles.mixText}>
              Chill Mix
            </Text>
          </TouchableOpacity>


          <TouchableOpacity style={styles.mixCard}>
            <View style={styles.mixArtwork} />

            <Text style={styles.mixText}>
              Focus Flow
            </Text>
          </TouchableOpacity>


          <TouchableOpacity style={styles.mixCard}>
            <View style={styles.mixArtwork} />

            <Text style={styles.mixText}>
              Workout Vibes
            </Text>
          </TouchableOpacity>


          <TouchableOpacity style={styles.mixCard}>
            <View style={styles.mixArtwork} />

            <Text style={styles.mixText}>
              Daily Mix
            </Text>
          </TouchableOpacity>

        </View>

      </ScrollView>


      {/* =====================================================
          MINI PLAYER
          Clicking the player opens PlayerScreen.
          ===================================================== */}

      <TouchableOpacity
        style={styles.player}
        activeOpacity={0.85}
        onPress={onPlayerPress}>

        <View style={styles.playerArtwork}>

          <View style={styles.playerArtworkRing} />

        </View>


        <View style={styles.playerInfo}>

          <Text style={styles.playerTitle}>
            Starlight
          </Text>

          <Text style={styles.playerArtist}>
            The Weeknd
          </Text>

        </View>


        {/* PAUSE */}

        <TouchableOpacity
          style={styles.playerButton}
          activeOpacity={0.7}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.pauseIcon}>
            ||
          </Text>

        </TouchableOpacity>


        {/* NEXT */}

        <TouchableOpacity
          style={styles.playerButton}
          activeOpacity={0.7}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.nextIcon}>
            ▷|
          </Text>

        </TouchableOpacity>

      </TouchableOpacity>

    </View>
  );
};


const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#050719',
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',

    paddingTop: (StatusBar.currentHeight || 24) + 4,

    paddingHorizontal: 8,
    paddingBottom: 12,
  },

  menuButton: {
    width: 34,
    height: 38,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 2,
  },

  menuLine: {
    width: 22,
    height: 2,

    backgroundColor: '#C5CBD9',

    marginVertical: 2.5,

    borderRadius: 2,
  },

  headerText: {
    flex: 1,
  },

  greeting: {
    color: '#F5F6FA',

    fontSize: 20,
    fontWeight: '700',
  },

  subtitle: {
    marginTop: 3,

    color: '#737C91',

    fontSize: 11,
  },

  scrollView: {
    flex: 1,
  },

  content: {
    paddingHorizontal: 8,
    paddingBottom: 86,
  },

  searchBar: {
    height: 50,

    borderRadius: 12,

    backgroundColor: '#07182E',

    borderWidth: 1,
    borderColor: '#17304F',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 13,

    marginBottom: 14,
  },

  searchIcon: {
    color: '#7E8CA5',

    fontSize: 24,

    marginRight: 9,
  },

  searchPlaceholder: {
    flex: 1,

    color: '#77839A',

    fontSize: 11,
  },

  micIcon: {
    color: '#8490A6',

    fontSize: 15,
  },

  heroCard: {
    height: 180,

    borderRadius: 10,

    backgroundColor: '#17203F',

    overflow: 'hidden',

    position: 'relative',

    marginBottom: 22,
  },

  heroText: {
    position: 'absolute',

    left: 17,
    top: 16,

    zIndex: 2,
  },

  heroEyebrow: {
    color: '#00BFFF',

    fontSize: 9,

    fontWeight: '700',

    marginBottom: 7,
  },

  heroTitle: {
    color: '#F5F6FA',

    fontSize: 25,

    fontWeight: '700',
  },

  heroSubtitle: {
    color: '#8D96AA',

    fontSize: 11,

    marginTop: 6,
  },

  heroArtwork: {
    position: 'absolute',

    right: 48,
    top: 13,

    width: 145,
    height: 145,

    alignItems: 'center',
    justifyContent: 'center',
  },

  heroArtworkRing: {
    width: 136,
    height: 136,

    borderRadius: 68,

    borderWidth: 2,

    borderColor: '#2D62E8',
  },

  heroArtworkBottom: {
    position: 'absolute',

    bottom: 4,

    width: 29,
    height: 43,

    borderRadius: 14,

    backgroundColor: '#111D3B',
  },

  playButton: {
    position: 'absolute',

    right: 15,
    bottom: 15,

    width: 46,
    height: 46,

    borderRadius: 23,

    backgroundColor: '#5869F2',

    alignItems: 'center',
    justifyContent: 'center',
  },

  playIcon: {
    color: '#FFFFFF',

    fontSize: 16,

    marginLeft: 2,
  },

  sectionHeader: {
    flexDirection: 'row',

    justifyContent: 'space-between',
    alignItems: 'center',

    marginBottom: 11,
  },

  sectionTitle: {
    color: '#F5F6FA',

    fontSize: 18,

    fontWeight: '700',
  },

  seeAll: {
    color: '#279BFF',

    fontSize: 10,

    fontWeight: '500',
  },

  recentRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    marginBottom: 22,
  },

  recentItem: {
    width: '31.8%',
  },

  albumPlaceholder: {
    height: 88,

    borderRadius: 9,

    backgroundColor: '#18223E',

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: 8,
  },

  albumRing: {
    width: 42,
    height: 42,

    borderRadius: 21,

    borderWidth: 2,

    borderColor: '#2860DF',
  },

  songTitle: {
    color: '#E6E9F0',

    fontSize: 11,

    fontWeight: '600',
  },

  artistName: {
    color: '#70798E',

    fontSize: 9,

    marginTop: 2,
  },

  mixGrid: {
    flexDirection: 'row',

    flexWrap: 'wrap',

    justifyContent: 'space-between',

    rowGap: 11,
  },

  mixCard: {
    width: '49%',

    height: 48,

    borderRadius: 9,

    backgroundColor: '#151F35',

    flexDirection: 'row',

    alignItems: 'center',

    overflow: 'hidden',
  },

  mixArtwork: {
    width: 50,

    height: '100%',

    backgroundColor: '#123250',
  },

  mixText: {
    color: '#DCE1EB',

    fontSize: 11,

    marginLeft: 11,

    fontWeight: '500',
  },

  /* =====================================================
     MINI PLAYER
     ===================================================== */

  player: {
    position: 'absolute',

    left: 8,
    right: 8,

    bottom: 64,

    height: 62,

    borderRadius: 10,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 9,
  },

  playerArtwork: {
    width: 44,
    height: 44,

    borderRadius: 8,

    backgroundColor: '#10284B',

    alignItems: 'center',
    justifyContent: 'center',
  },

  playerArtworkRing: {
    width: 21,
    height: 21,

    borderRadius: 11,

    borderWidth: 1.5,

    borderColor: '#2860DF',
  },

  playerInfo: {
    flex: 1,

    marginLeft: 10,
  },

  playerTitle: {
    color: '#E8EBF2',

    fontSize: 11,

    fontWeight: '600',
  },

  playerArtist: {
    color: '#778196',

    fontSize: 9,

    marginTop: 2,
  },

  playerButton: {
    width: 38,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },

  pauseIcon: {
    color: '#E9ECF3',

    fontSize: 19,

    fontWeight: '600',
  },

  nextIcon: {
    color: '#E9ECF3',

    fontSize: 20,
  },

});

export default HomeScreen;