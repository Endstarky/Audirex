import React, {useEffect, useState} from 'react';
import {
  ActivityIndicator,
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {
  getLocalSongs,
  LocalSong,
  requestMusicPermission,
} from '../services/localMusic';

type AllSongsScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

type Song = LocalSong;

const AllSongsScreen = ({
  onMenuPress,
  onPlayerPress,
}: AllSongsScreenProps) => {

  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);

  /* =========================================================
     LOAD LOCAL SONGS
     ========================================================= */

  useEffect(() => {
    loadSongs();
  }, []);

  const loadSongs = async () => {

    try {

      setLoading(true);

      const permissionGranted = await requestMusicPermission();

      if (!permissionGranted) {
        setSongs([]);
        return;
      }

      setSongs(await getLocalSongs());

    } catch (error) {

      console.log(
        'Error loading local songs:',
        error,
      );

      setSongs([]);

    } finally {

      setLoading(false);

    }
  };


  /* =========================================================
     FORMAT DURATION
     ========================================================= */

  const formatDuration = (
    duration?: number,
  ) => {

    if (!duration) {
      return '';
    }

    const totalSeconds =
      Math.floor(duration / 1000);

    const minutes =
      Math.floor(totalSeconds / 60);

    const seconds =
      totalSeconds % 60;

    return `${minutes}:${seconds
      .toString()
      .padStart(2, '0')}`;
  };


  /* =========================================================
     SONG PRESS
     ========================================================= */

  const handleSongPress = (song: Song) => {

    /*
     * This will later start playback and update
     * the global mini-player.
     */

    console.log(
      'Song pressed:',
      song.title,
    );
  };


  /* =========================================================
     RENDER
     ========================================================= */

  return (
    <SafeAreaView style={styles.container}>

      {/* =====================================================
          HEADER
          ===================================================== */}

      <View style={styles.header}>

        {/* SIDEBAR */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <View style={styles.headerTitleContainer}>

          <Text style={styles.headerTitle}>
            All Songs
          </Text>

          <Text style={styles.headerSubtitle}>
            {songs.length} songs
          </Text>

        </View>


        {/* SEARCH */}

        <Pressable
          style={styles.searchButton}>

          <Text style={styles.searchIcon}>
            ⌕
          </Text>

        </Pressable>

      </View>


      {/* =====================================================
          SONG LIST
          ===================================================== */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>

        {/* SORT */}

        <View style={styles.sortRow}>

          <Text style={styles.sortLabel}>
            All songs
          </Text>

          <Pressable style={styles.sortButton}>

            <Text style={styles.sortIcon}>
              ↕
            </Text>

            <Text style={styles.sortText}>
              Recently added
            </Text>

          </Pressable>

        </View>


        {/* LOADING */}

        {loading && (

          <View style={styles.stateContainer}>

            <ActivityIndicator
              size="small"
              color="#5869F2"
            />

            <Text style={styles.stateText}>
              Loading songs...
            </Text>

          </View>

        )}


        {/* EMPTY */}

        {!loading &&
          songs.length === 0 && (

            <View style={styles.emptyContainer}>

              <View style={styles.emptyIconContainer}>

                <Text style={styles.emptyIcon}>
                  ♪
                </Text>

              </View>

              <Text style={styles.emptyTitle}>
                No songs found
              </Text>

              <Text style={styles.emptySubtitle}>
                Music stored on your device will
                appear here.
              </Text>

            </View>

        )}


        {/* SONGS */}

        {!loading &&
          songs.length > 0 && (

            <View style={styles.songList}>

              {songs.map((song, index) => (

                <Pressable
                  key={song.id || `${song.title}-${index}`}
                  style={styles.songItem}
                  onPress={() =>
                    handleSongPress(song)
                  }>

                  {/* ARTWORK */}

                  <View style={styles.songArtwork}>

                    {song.artwork ? (

                      <Image
                        source={{
                          uri: song.artwork,
                        }}
                        style={styles.artworkImage}
                      />

                    ) : (

                      <Text style={styles.artworkIcon}>
                        ♪
                      </Text>

                    )}

                  </View>


                  {/* INFO */}

                  <View style={styles.songInfo}>

                    <Text
                      style={styles.songTitle}
                      numberOfLines={1}>

                      {song.title}

                    </Text>

                    <Text
                      style={styles.songArtist}
                      numberOfLines={1}>

                      {song.artist ||
                        'Unknown artist'}

                    </Text>

                  </View>


                  {/* DURATION */}

                  {song.duration && (

                    <Text style={styles.duration}>
                      {formatDuration(
                        song.duration,
                      )}
                    </Text>

                  )}


                  {/* MORE */}

                  <Pressable
                    style={styles.moreButton}>

                    <Text style={styles.moreIcon}>
                      ⋮
                    </Text>

                  </Pressable>

                </Pressable>

              ))}

            </View>

        )}

      </ScrollView>


      {/* =====================================================
          MINI PLAYER
          ===================================================== */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}>

        {/* ARTWORK */}

        <View style={styles.miniArtwork} />

        {/* INFO */}

        <View style={styles.miniInfo}>

          <Text style={styles.miniTitle}>
            No song playing
          </Text>

          <Text style={styles.miniArtist}>
            Nothing is currently playing
          </Text>

        </View>


        {/* PLAY */}

        <Pressable
          style={styles.miniButton}>

          <Text style={styles.miniPlay}>
            ▶
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable
          style={styles.miniButton}>

          <Text style={styles.miniNext}>
            ▷|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


/* =============================================================
   STYLES
   ============================================================= */

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 92,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 12,

    paddingTop: 10,
  },


  menuButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 7,
  },


  menuLine: {
    width: 27,
    height: 2.5,

    backgroundColor: '#C9D0DE',

    marginVertical: 3,

    borderRadius: 2,
  },


  headerTitleContainer: {
    flex: 1,

    justifyContent: 'center',
  },


  headerTitle: {
    color: '#F5F6FA',

    fontSize: 24,

    fontWeight: '700',
  },


  headerSubtitle: {
    color: '#737C91',

    fontSize: 11,

    marginTop: 3,
  },


  searchButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D6DCE8',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -4,
  },


  /* =========================================================
     SCROLL
     ========================================================= */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 12,

    paddingTop: 8,

    paddingBottom: 145,
  },


  /* =========================================================
     SORT
     ========================================================= */

  sortRow: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',

    marginBottom: 15,

    paddingHorizontal: 2,
  },


  sortLabel: {
    color: '#E7EAF1',

    fontSize: 16,

    fontWeight: '700',
  },


  sortButton: {
    flexDirection: 'row',

    alignItems: 'center',

    paddingVertical: 5,
  },


  sortIcon: {
    color: '#9BA5B8',

    fontSize: 19,

    marginRight: 5,
  },


  sortText: {
    color: '#9BA5B8',

    fontSize: 12,

    fontWeight: '500',
  },


  /* =========================================================
     SONG LIST
     ========================================================= */

  songList: {
    width: '100%',
  },


  songItem: {
    minHeight: 76,

    flexDirection: 'row',

    alignItems: 'center',

    marginBottom: 6,
  },


  songArtwork: {
    width: 62,
    height: 62,

    borderRadius: 9,

    backgroundColor: '#101B31',

    alignItems: 'center',
    justifyContent: 'center',

    overflow: 'hidden',
  },


  artworkImage: {
    width: '100%',
    height: '100%',
  },


  artworkIcon: {
    color: '#5265E9',

    fontSize: 25,
  },


  songInfo: {
    flex: 1,

    marginLeft: 14,

    justifyContent: 'center',
  },


  songTitle: {
    color: '#EEF0F5',

    fontSize: 15,

    fontWeight: '700',
  },


  songArtist: {
    color: '#7C879C',

    fontSize: 11,

    marginTop: 5,
  },


  duration: {
    color: '#737E94',

    fontSize: 11,

    marginRight: 4,
  },


  moreButton: {
    width: 42,
    height: 60,

    alignItems: 'center',
    justifyContent: 'center',
  },


  moreIcon: {
    color: '#AAB3C4',

    fontSize: 25,

    fontWeight: '700',
  },


  /* =========================================================
     EMPTY / LOADING
     ========================================================= */

  stateContainer: {
    alignItems: 'center',

    justifyContent: 'center',

    paddingTop: 100,
  },


  stateText: {
    color: '#788399',

    fontSize: 12,

    marginTop: 12,
  },


  emptyContainer: {
    alignItems: 'center',

    justifyContent: 'center',

    paddingTop: 85,

    paddingHorizontal: 35,
  },


  emptyIconContainer: {
    width: 76,
    height: 76,

    borderRadius: 38,

    backgroundColor: '#111C34',

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: 18,
  },


  emptyIcon: {
    color: '#5265E9',

    fontSize: 34,
  },


  emptyTitle: {
    color: '#E9ECF2',

    fontSize: 18,

    fontWeight: '700',
  },


  emptySubtitle: {
    color: '#707B91',

    fontSize: 12,

    textAlign: 'center',

    lineHeight: 18,

    marginTop: 8,
  },


  /* =========================================================
     MINI PLAYER
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 82,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 10,

    elevation: 8,
  },


  miniArtwork: {
    width: 52,
    height: 52,

    borderRadius: 9,

    backgroundColor: '#10284B',
  },


  miniInfo: {
    flex: 1,

    marginLeft: 12,
  },


  miniTitle: {
    color: '#EEF0F5',

    fontSize: 14,

    fontWeight: '700',
  },


  miniArtist: {
    color: '#808BA0',

    fontSize: 11,

    marginTop: 3,
  },


  miniButton: {
    width: 46,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  miniPlay: {
    color: '#F1F3F7',

    fontSize: 19,
  },


  miniNext: {
    color: '#F1F3F7',

    fontSize: 21,
  },

});

export default AllSongsScreen;
