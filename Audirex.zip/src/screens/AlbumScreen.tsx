import React from 'react';
import {
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type AlbumScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

const AlbumScreen = ({
  onMenuPress,
  onPlayerPress,
}: AlbumScreenProps) => {

  const albums = [
    {
      title: 'Unknown Album',
      artist: 'Unknown, 031974_30...',
      tracks: 66,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '1 2 3',
      artist: 'THIRST',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '1 Am. Study Session',
      artist: 'mell-ø',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '13 Reasons Why (S...',
      artist: 'Lord Huron, Phoebe...',
      tracks: 2,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '1998',
      artist: 'Snoblack, Phonkomo...',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '1AM',
      artist: 'THIRST',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: 'Immortal',
      artist: 'Cash!',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '3 Am. Study Session',
      artist: 'TABAL, mell-ø, Yasu...',
      tracks: 2,
      image: require('../../assets/starlight.jpg'),
    },
    {
      title: '6',
      artist: 'Heleza',
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
  ];

  return (
    <SafeAreaView style={styles.container}>

      {/* =====================================================
          HEADER
          ===================================================== */}

      <View style={styles.header}>

        {/* SIDEBAR */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}
          android_ripple={{
            color: '#182744',
            borderless: true,
          }}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <Text style={styles.headerTitle}>
          Albums
        </Text>


        <View style={styles.headerActions}>

          {/* SEARCH */}

          <Pressable style={styles.headerButton}>

            <Text style={styles.searchIcon}>
              ⌕
            </Text>

          </Pressable>


          {/* MORE */}

          <Pressable style={styles.headerButton}>

            <Text style={styles.headerMore}>
              ⋮
            </Text>

          </Pressable>

        </View>

      </View>


      {/* =====================================================
          ALBUM GRID
          ===================================================== */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>

        <View style={styles.albumGrid}>

          {albums.map((album, index) => (

            <Pressable
              key={`${album.title}-${index}`}
              style={styles.albumCard}>

              {/* ARTWORK */}

              <View style={styles.albumArtwork}>

                <Image
                  source={album.image}
                  style={styles.albumImage}
                  resizeMode="cover"
                />


                {/* PLAY BUTTON */}

                <Pressable
                  style={styles.playButton}
                  onPress={() => {}}>

                  <Text style={styles.playIcon}>
                    ▶
                  </Text>

                </Pressable>

              </View>


              {/* INFORMATION */}

              <View style={styles.albumInfo}>

                <Text
                  style={styles.albumTitle}
                  numberOfLines={1}>

                  {album.title}

                </Text>


                <Text
                  style={styles.albumArtist}
                  numberOfLines={1}>

                  {album.artist}

                </Text>


                <View style={styles.albumBottomRow}>

                  <Text style={styles.trackCount}>
                    Tracks: {album.tracks}
                  </Text>


                  <Pressable style={styles.moreButton}>

                    <Text style={styles.moreIcon}>
                      ⋮
                    </Text>

                  </Pressable>

                </View>

              </View>

            </Pressable>

          ))}

        </View>

      </ScrollView>


      {/* =====================================================
          MINI PLAYER
          ===================================================== */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}
        android_ripple={{
          color: '#203452',
        }}>

        {/* ARTWORK */}

        <View style={styles.miniArtwork}>

          <Image
            source={require('../../assets/starlight.jpg')}
            style={styles.miniArtworkImage}
            resizeMode="cover"
          />

        </View>


        {/* SONG INFORMATION */}

        <View style={styles.miniInfo}>

          <Text
            style={styles.miniTitle}
            numberOfLines={1}>

            Starlight

          </Text>

          <Text
            style={styles.miniArtist}
            numberOfLines={1}>

            The Weeknd

          </Text>

        </View>


        {/* PAUSE */}

        <Pressable
          style={styles.miniButton}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniPause}>
            Ⅱ
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable
          style={styles.miniButton}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniNext}>
            ▷|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


/* =============================================================
   STYLES
   ============================================================= */

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 82,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 12,

    paddingTop: 10,
  },


  menuButton: {
    width: 50,
    height: 50,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 4,
  },


  menuLine: {
    width: 29,
    height: 2.5,

    backgroundColor: '#C9D1E0',

    marginVertical: 3,

    borderRadius: 2,
  },


  headerTitle: {
    flex: 1,

    color: '#F5F6FA',

    fontSize: 24,

    fontWeight: '700',

    marginLeft: 4,
  },


  headerActions: {
    flexDirection: 'row',

    alignItems: 'center',
  },


  headerButton: {
    width: 45,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D7DDEA',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -4,
  },


  headerMore: {
    color: '#C8D0DE',

    fontSize: 28,

    fontWeight: '700',
  },


  /* =========================================================
     SCROLL
     ========================================================= */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 10,

    paddingTop: 8,

    paddingBottom: 125,
  },


  /* =========================================================
     GRID
     ========================================================= */

  albumGrid: {
    flexDirection: 'row',

    flexWrap: 'wrap',

    justifyContent: 'space-between',

    rowGap: 14,
  },


  albumCard: {
    width: '31.8%',

    backgroundColor: '#10182A',

    borderRadius: 10,

    overflow: 'hidden',
  },


  /* =========================================================
     ARTWORK
     ========================================================= */

  albumArtwork: {
    width: '100%',

    aspectRatio: 1,

    backgroundColor: '#111A2E',

    position: 'relative',
  },


  albumImage: {
    width: '100%',
    height: '100%',
  },


  playButton: {
    position: 'absolute',

    right: 8,
    bottom: 8,

    width: 36,
    height: 36,

    borderRadius: 18,

    backgroundColor: '#F4F5F8',

    alignItems: 'center',
    justifyContent: 'center',

    elevation: 4,
  },


  playIcon: {
    color: '#20283A',

    fontSize: 14,

    marginLeft: 2,
  },


  /* =========================================================
     ALBUM INFORMATION
     ========================================================= */

  albumInfo: {
    paddingHorizontal: 10,

    paddingTop: 9,

    paddingBottom: 8,
  },


  albumTitle: {
    color: '#EEF1F6',

    fontSize: 14,

    fontWeight: '700',
  },


  albumArtist: {
    color: '#818CA1',

    fontSize: 11,

    marginTop: 4,
  },


  albumBottomRow: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',

    marginTop: 2,
  },


  trackCount: {
    color: '#69758C',

    fontSize: 10,

    flex: 1,
  },


  moreButton: {
    width: 30,
    height: 34,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: -4,
  },


  moreIcon: {
    color: '#929DB1',

    fontSize: 23,

    fontWeight: '700',
  },


  /* =========================================================
     MINI PLAYER
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 64,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    borderWidth: 1,

    borderColor: '#203453',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 10,

    elevation: 10,
  },


  miniArtwork: {
    width: 52,
    height: 52,

    borderRadius: 9,

    overflow: 'hidden',

    backgroundColor: '#10284B',
  },


  miniArtworkImage: {
    width: '100%',
    height: '100%',
  },


  miniInfo: {
    flex: 1,

    marginLeft: 12,
  },


  miniTitle: {
    color: '#EEF1F6',

    fontSize: 14,

    fontWeight: '700',
  },


  miniArtist: {
    color: '#818CA1',

    fontSize: 11,

    marginTop: 3,
  },


  miniButton: {
    width: 46,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  miniPause: {
    color: '#F2F4F8',

    fontSize: 21,

    fontWeight: '600',
  },


  miniNext: {
    color: '#F2F4F8',

    fontSize: 21,
  },

});

export default AlbumScreen;