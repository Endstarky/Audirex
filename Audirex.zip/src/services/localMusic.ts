import {NativeModules, PermissionsAndroid, Platform} from 'react-native';

export type LocalSong = {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  artwork?: string;
  path: string;
  uri: string;
  albumId?: string;
};

type LocalMusicModule = {
  getSongs(query?: string): Promise<LocalSong[]>;
};

const {LocalMusic} = NativeModules as {LocalMusic?: LocalMusicModule};

export const requestMusicPermission = async (): Promise<boolean> => {
  if (Platform.OS !== 'android') {
    return false;
  }

  const permission =
    Platform.Version >= 33
      ? PermissionsAndroid.PERMISSIONS.READ_MEDIA_AUDIO
      : PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE;

  const result = await PermissionsAndroid.request(permission);
  return result === PermissionsAndroid.RESULTS.GRANTED;
};

/** Reads tracks indexed on this device. No network service is used. */
export const getLocalSongs = async (query = ''): Promise<LocalSong[]> => {
  if (Platform.OS !== 'android' || !LocalMusic) {
    return [];
  }

  return LocalMusic.getSongs(query);
};
