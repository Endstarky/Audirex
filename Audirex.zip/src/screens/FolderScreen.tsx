import React from 'react';
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

type FolderScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

/*
  Temporary folder data.

  Later, this can be replaced with folders discovered
  from the device's local storage.
*/
const folders = [
  'Music',
  'Downloads',
  'WhatsApp Audio',
  'Telegram',
  'Recordings',
];

const FolderScreen = ({
  onMenuPress,
  onPlayerPress,
}: FolderScreenProps) => {
  return (
    <View style={styles.container}>

      {/* =====================================================
          HEADER
          ===================================================== */}

      <View style={styles.header}>

        <TouchableOpacity
          style={styles.menuButton}
          activeOpacity={0.75}
          onPress={onMenuPress}>

          <Text style={styles.menuIcon}>
            ☰
          </Text>

        </TouchableOpacity>

        <Text style={styles.headerTitle}>
          Folders
        </Text>

      </View>

      {/* =====================================================
          FOLDER LIST
          ===================================================== */}

      <View style={styles.content}>

        {folders.map((folder, index) => (

          <TouchableOpacity
            key={`${folder}-${index}`}
            style={styles.folderItem}
            activeOpacity={0.75}
            onPress={() => {
              console.log(`Folder pressed: ${folder}`);
            }}>

            {/* FOLDER ICON */}

            <Image
              source={require('../../assets/icons/single-folder.png')}
              style={styles.folderIcon}
              resizeMode="contain"
            />

            {/* FOLDER NAME */}

            <Text
              style={styles.folderName}
              numberOfLines={1}>

              {folder}

            </Text>

          </TouchableOpacity>

        ))}

      </View>

      {/* =====================================================
          MINI PLAYER
          ===================================================== */}

      <View style={styles.miniPlayer}>

        {/* LEFT SIDE */}

        <View style={styles.miniPlayerLeft}>

          <View style={styles.miniPlayerPlaceholder}>

            <Text style={styles.musicNote}>
              ♪
            </Text>

          </View>

          <View style={styles.miniPlayerInfo}>

            <Text
              style={styles.miniPlayerTitle}
              numberOfLines={1}>

              No song playing

            </Text>

            <Text
              style={styles.miniPlayerArtist}
              numberOfLines={1}>

              —

            </Text>

          </View>

        </View>


        {/* ===================================================
            CONTROLS
            =================================================== */}

        <View style={styles.controls}>

          {/* PREVIOUS */}

          <Pressable
            style={styles.miniButton}
            disabled>

            <Text style={styles.previousIcon}>
              |◀
            </Text>

          </Pressable>


          {/* PLAY */}

          <Pressable
            style={styles.playButton}
            onPress={onPlayerPress}>

            <Text style={styles.playIcon}>
              ▶
            </Text>

          </Pressable>


          {/* NEXT */}

          <Pressable
            style={styles.miniButton}
            disabled>

            <Text style={styles.nextIcon}>
              ▶|
            </Text>

          </Pressable>

        </View>

      </View>

    </View>
  );
};

const styles = StyleSheet.create({

  /* =========================================================
     CONTAINER
     ========================================================= */

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 76,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 16,
  },

  menuButton: {
    width: 44,
    height: 44,

    alignItems: 'center',
    justifyContent: 'center',
  },

  menuIcon: {
    color: '#FFFFFF',

    fontSize: 27,
  },

  headerTitle: {
    color: '#FFFFFF',

    fontSize: 24,
    fontWeight: '700',

    marginLeft: 8,
  },


  /* =========================================================
     CONTENT
     ========================================================= */

  content: {
    flex: 1,

    paddingHorizontal: 16,
    paddingTop: 8,

    paddingBottom: 100,
  },


  /* =========================================================
     FOLDER ITEM
     ========================================================= */

  folderItem: {
    height: 68,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 14,

    marginBottom: 6,

    borderRadius: 10,

    backgroundColor: '#0A1023',
  },

  folderIcon: {
    width: 38,
    height: 38,

    marginRight: 16,
  },

  folderName: {
    flex: 1,

    color: '#E7EAF2',

    fontSize: 16,
    fontWeight: '600',
  },


  /* =========================================================
     MINI PLAYER
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 62,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 8,

    elevation: 8,
  },


  /* =========================================================
     MINI PLAYER LEFT
     ========================================================= */

  miniPlayerLeft: {
    flex: 1,

    flexDirection: 'row',

    alignItems: 'center',

    marginRight: 8,
  },

  miniPlayerPlaceholder: {
    width: 48,
    height: 48,

    borderRadius: 7,

    backgroundColor: '#1A2340',

    alignItems: 'center',
    justifyContent: 'center',
  },

  musicNote: {
    color: '#69759A',

    fontSize: 22,
  },

  miniPlayerInfo: {
    flex: 1,

    marginLeft: 10,
  },

  miniPlayerTitle: {
    color: '#DDE2EF',

    fontSize: 14,
    fontWeight: '600',
  },

  miniPlayerArtist: {
    color: '#737E98',

    fontSize: 12,

    marginTop: 3,
  },


  /* =========================================================
     CONTROLS
     ========================================================= */

  controls: {
    flexDirection: 'row',

    alignItems: 'center',
  },

  miniButton: {
    width: 48,
    height: 60,

    alignItems: 'center',
    justifyContent: 'center',
  },

  previousIcon: {
    color: '#EEF1F6',

    fontSize: 21,

    fontWeight: '600',
  },

  nextIcon: {
    color: '#EEF1F6',

    fontSize: 21,

    fontWeight: '600',
  },

  playButton: {
    width: 54,
    height: 54,

    borderRadius: 27,

    alignItems: 'center',
    justifyContent: 'center',

    backgroundColor: '#5369F2',

    marginHorizontal: 3,
  },

  playIcon: {
    color: '#FFFFFF',

    fontSize: 20,

    marginLeft: 3,
  },

});

export default FolderScreen;