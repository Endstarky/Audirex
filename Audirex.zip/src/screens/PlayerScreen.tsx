import React, {useState} from 'react';
import {
  Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type PlayerScreenProps = {
  onBack: () => void;
};

type RepeatMode = 'off' | 'all' | 'one';

const PlayerScreen = ({onBack}: PlayerScreenProps) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [liked, setLiked] = useState(false);
  const [shuffleEnabled, setShuffleEnabled] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');

  const cycleRepeatMode = () => {
    if (repeatMode === 'off') {
      setRepeatMode('all');
    } else if (repeatMode === 'all') {
      setRepeatMode('one');
    } else {
      setRepeatMode('off');
    }
  };

  const getRepeatIcon = () => {
    if (repeatMode === 'one') {
      return require('../../assets/icons/repeat-same-track.png');
    }

    if (repeatMode === 'all') {
      return require('../../assets/icons/repeat-enabled.png');
    }

    return require('../../assets/icons/repeat.png');
  };

  return (
    <SafeAreaView style={styles.container}>

      {/* =========================================================
          HEADER
          ========================================================= */}

      <View style={styles.header}>

        <Pressable
          style={styles.headerButton}
          onPress={onBack}>

          <Text style={styles.backIcon}>‹</Text>

        </Pressable>

        <Text style={styles.headerTitle}>
          Now Playing
        </Text>

        <Pressable style={styles.headerButton}>

          <Text style={styles.queueIcon}>
            ≡♫
          </Text>

        </Pressable>

      </View>


      {/* =========================================================
          PLAYING FROM
          ========================================================= */}

      <View style={styles.sourceRow}>

        <Text style={styles.sourceText}>
          PLAYING FROM MY PLAYLIST
        </Text>

        <View style={styles.sourceActions}>

          {/* MOON */}

          <Pressable style={styles.sourceButton}>

            <View style={styles.sourceIconWrapper}>

              <Image
                source={require('../../assets/icons/moon.png')}
                resizeMode="contain"
                style={styles.downloadedSourceIcon}
              />

            </View>

          </Pressable>


          {/* SHARE */}

          <Pressable style={styles.sourceButton}>

            <View style={styles.sourceIconWrapper}>

              <Image
                source={require('../../assets/icons/share.png')}
                resizeMode="contain"
                style={styles.downloadedSourceIcon}
              />

            </View>

          </Pressable>

        </View>

      </View>


      {/* =========================================================
          ALBUM ART
          ========================================================= */}

      <View style={styles.albumContainer}>

        <Image
          source={require('../../assets/starlight.jpg')}
          style={styles.albumArt}
          resizeMode="cover"
        />

      </View>


      {/* =========================================================
          SONG INFORMATION
          ========================================================= */}

      <View style={styles.songInfo}>

        <View style={styles.songTextContainer}>

          <Text
            style={styles.songTitle}
            numberOfLines={1}>

            Starlight

          </Text>

          <Text
            style={styles.artist}
            numberOfLines={1}>

            The Weeknd

          </Text>

        </View>


        {/* LIKE */}

        <Pressable
          style={styles.heartButton}
          onPress={() => setLiked(!liked)}>

          <View style={styles.likeIconWrapper}>

            <Image
              source={
                liked
                  ? require('../../assets/icons/liked.png')
                  : require('../../assets/icons/like.png')
              }
              resizeMode="contain"
              style={styles.downloadedLikeIcon}
            />

          </View>

        </Pressable>

      </View>


      {/* =========================================================
          PROGRESS
          ========================================================= */}

      <View style={styles.progressSection}>

        <View style={styles.progressTrack}>

          <View style={styles.progressFill} />

          <View style={styles.progressKnob} />

        </View>

        <View style={styles.timeRow}>

          <Text style={styles.timeText}>
            1:24
          </Text>

          <Text style={styles.timeText}>
            3:42
          </Text>

        </View>

      </View>


      {/* =========================================================
          MAIN CONTROLS
          ========================================================= */}

      <View style={styles.controls}>

        {/* SHUFFLE */}

        <Pressable
          style={styles.controlButton}
          onPress={() => setShuffleEnabled(!shuffleEnabled)}>

          <View style={styles.mainIconWrapper}>

            <Image
              source={
                shuffleEnabled
                  ? require('../../assets/icons/shuffle-enabled.png')
                  : require('../../assets/icons/shuffle.png')
              }
              resizeMode="contain"
              style={styles.downloadedMainIcon}
            />

          </View>

        </Pressable>


        {/* PREVIOUS */}

        <Pressable style={styles.controlButton}>

          <Text style={styles.previousIcon}>
            |◀
          </Text>

        </Pressable>


        {/* PLAY / PAUSE */}

        <Pressable
          style={styles.playButton}
          onPress={() => setIsPlaying(!isPlaying)}>

          <Text style={styles.playPauseIcon}>
            {isPlaying ? 'Ⅱ' : '▶'}
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable style={styles.controlButton}>

          <Text style={styles.nextIcon}>
            ▶|
          </Text>

        </Pressable>


        {/* REPEAT */}

        <Pressable
          style={styles.controlButton}
          onPress={cycleRepeatMode}>

          <View style={styles.mainIconWrapper}>

            <Image
              source={getRepeatIcon()}
              resizeMode="contain"
              style={styles.downloadedMainIcon}
            />

          </View>

        </Pressable>

      </View>


      {/* =========================================================
          SECONDARY CONTROLS
          ========================================================= */}

      <View style={styles.secondaryControls}>

        {/* LYRICS */}

        <Pressable style={styles.secondaryButton}>

          <View style={styles.secondaryIconWrapper}>

            <Image
              source={require('../../assets/icons/lyrics.png')}
              resizeMode="contain"
              style={styles.downloadedSecondaryIcon}
            />

          </View>

          <Text style={styles.secondaryText}>
            Lyrics
          </Text>

        </Pressable>


        {/* EQUALIZER */}

        <Pressable style={styles.secondaryButton}>

          <View style={styles.secondaryIconWrapper}>

            <Image
              source={require('../../assets/icons/equalizer.png')}
              resizeMode="contain"
              style={styles.downloadedSecondaryIcon}
            />

          </View>

          <Text style={styles.secondaryText}>
            Equalizer
          </Text>

        </Pressable>


        {/* THIS DEVICE */}

        <Pressable style={styles.secondaryButton}>

          <View style={styles.secondaryIconWrapper}>

            <Image
              source={require('../../assets/icons/this-device.png')}
              resizeMode="contain"
              style={styles.downloadedSecondaryIcon}
            />

          </View>

          <Text style={styles.secondaryText}>
            This device
          </Text>

        </Pressable>

      </View>


      {/* =========================================================
          BOTTOM WAVEFORM
          ========================================================= */}

      <View style={styles.bottomWaveform}>

        {[
          5, 8, 12, 7, 16, 10, 19, 8,
          14, 6, 17, 11, 7, 15, 9, 13,
          6, 10, 5, 8, 4,
        ].map((height, index) => (

          <View
            key={index}
            style={[
              styles.waveBar,
              {height},
            ]}
          />

        ))}

      </View>

    </SafeAreaView>
  );
};


const styles = StyleSheet.create({

  /* =========================================================
     CONTAINER
     ========================================================= */

  container: {
    flex: 1,
    backgroundColor: '#090F22',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 70,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 18,
  },

  headerButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },

  backIcon: {
    color: '#E8EBF5',

    fontSize: 42,

    fontWeight: '300',

    marginTop: -5,
  },

  headerTitle: {
    flex: 1,

    textAlign: 'center',

    color: '#F4F5FA',

    fontSize: 18,

    fontWeight: '700',
  },

  queueIcon: {
    color: '#E3E7F2',

    fontSize: 24,

    fontWeight: '500',
  },


  /* =========================================================
     SOURCE
     ========================================================= */

  sourceRow: {
    height: 66,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 27,

    marginTop: 4,
  },

  sourceText: {
    flex: 1,

    color: '#778197',

    fontSize: 10,

    fontWeight: '500',

    letterSpacing: 0.3,
  },

  sourceActions: {
    flexDirection: 'row',

    alignItems: 'center',
  },

  sourceButton: {
    width: 44,
    height: 44,

    alignItems: 'center',
    justifyContent: 'center',

    marginLeft: 5,
  },


  /* =========================================================
     SOURCE DOWNLOADED ICONS
     ========================================================= */

  sourceIconWrapper: {
    width: 30,
    height: 30,

    alignItems: 'center',
    justifyContent: 'center',

    overflow: 'visible',
  },

  downloadedSourceIcon: {
    position: 'absolute',

    width: 128,
    height: 128,

    left: -49,
    top: -49,

    resizeMode: 'contain',

    transform: [
      {
        scale: 0.234,
      },
    ],
  },


  /* =========================================================
     ALBUM ART
     ========================================================= */

  albumContainer: {
    width: '78%',

    aspectRatio: 1,

    alignSelf: 'center',

    borderRadius: 18,

    overflow: 'hidden',

    backgroundColor: '#111B35',

    marginTop: 7,
  },

  albumArt: {
    width: '100%',
    height: '100%',
  },


  /* =========================================================
     SONG INFORMATION
     ========================================================= */

  songInfo: {
    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 27,

    marginTop: 22,
  },

  songTextContainer: {
    flex: 1,
  },

  songTitle: {
    color: '#F5F6FA',

    fontSize: 31,

    fontWeight: '700',
  },

  artist: {
    color: '#8A94AA',

    fontSize: 18,

    marginTop: 5,
  },

  heartButton: {
    width: 50,
    height: 50,

    alignItems: 'center',
    justifyContent: 'center',
  },


  /* =========================================================
     LIKE
     ========================================================= */

  likeIconWrapper: {
    width: 32,
    height: 32,

    alignItems: 'center',
    justifyContent: 'center',

    overflow: 'visible',
  },

  downloadedLikeIcon: {
    position: 'absolute',

    width: 128,
    height: 128,

    left: -48,
    top: -48,

    resizeMode: 'contain',

    transform: [
      {
        scale: 0.25,
      },
    ],
  },


  /* =========================================================
     PROGRESS
     ========================================================= */

  progressSection: {
    marginTop: 24,

    paddingHorizontal: 27,
  },

  progressTrack: {
    height: 5,

    borderRadius: 5,

    backgroundColor: '#202C4B',

    position: 'relative',
  },

  progressFill: {
    position: 'absolute',

    left: 0,
    top: 0,
    bottom: 0,

    width: '40%',

    borderRadius: 5,

    backgroundColor: '#3E7CFF',
  },

  progressKnob: {
    position: 'absolute',

    width: 12,
    height: 12,

    borderRadius: 6,

    backgroundColor: '#F5F6FA',

    left: '40%',

    top: -3.5,
  },

  timeRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    marginTop: 9,
  },

  timeText: {
    color: '#858FA4',

    fontSize: 11,
  },


  /* =========================================================
     MAIN CONTROLS
     ========================================================= */

  controls: {
    height: 104,

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',

    paddingHorizontal: 27,

    marginTop: 7,
  },

  controlButton: {
    width: 50,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  /* =========================================================
     MAIN DOWNLOADED ICONS
     ========================================================= */

  mainIconWrapper: {
    width: 34,
    height: 34,

    alignItems: 'center',
    justifyContent: 'center',

    overflow: 'visible',
  },

  downloadedMainIcon: {
    position: 'absolute',

    width: 128,
    height: 128,

    left: -47,
    top: -47,

    resizeMode: 'contain',

    transform: [
      {
        scale: 0.265,
      },
    ],
  },


  /* =========================================================
     PREVIOUS / NEXT
     ========================================================= */

  previousIcon: {
    color: '#EDF0F6',

    fontSize: 25,

    fontWeight: '400',
  },

  nextIcon: {
    color: '#EDF0F6',

    fontSize: 25,

    fontWeight: '400',
  },


  /* =========================================================
     PLAY / PAUSE
     ========================================================= */

  playButton: {
    width: 74,
    height: 74,

    borderRadius: 37,

    backgroundColor: '#6354F6',

    alignItems: 'center',
    justifyContent: 'center',

    elevation: 5,
  },

  playPauseIcon: {
    color: '#FFFFFF',

    fontSize: 36,

    fontWeight: '600',
  },


  /* =========================================================
     SECONDARY CONTROLS
     ========================================================= */

  secondaryControls: {
    height: 68,

    marginHorizontal: 27,

    borderRadius: 14,

    backgroundColor: '#101D35',

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-around',

    marginTop: 10,
  },

  secondaryButton: {
    flex: 1,

    height: '100%',

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',
  },


  /* =========================================================
     SECONDARY DOWNLOADED ICONS
     ========================================================= */

  secondaryIconWrapper: {
    width: 30,
    height: 30,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 7,

    overflow: 'visible',
  },

  downloadedSecondaryIcon: {
    position: 'absolute',

    width: 128,
    height: 128,

    left: -49,
    top: -49,

    resizeMode: 'contain',

    transform: [
      {
        scale: 0.234,
      },
    ],
  },

  secondaryText: {
    color: '#A6AEC0',

    fontSize: 15,

    fontWeight: '600',
  },


  /* =========================================================
     WAVEFORM
     ========================================================= */

  bottomWaveform: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',

    height: 36,

    marginTop: 14,

    gap: 4,
  },

  waveBar: {
    width: 3,

    borderRadius: 3,

    backgroundColor: '#293FAE',
  },

});

export default PlayerScreen;