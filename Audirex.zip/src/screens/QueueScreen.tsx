import React from 'react';
import {
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type QueueScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

const QueueScreen = ({
  onMenuPress,
  onPlayerPress,
}: QueueScreenProps) => {
  return (
    <SafeAreaView style={styles.container}>

      {/* =========================================================
          HEADER
          ========================================================= */}

      <View style={styles.header}>

        {/* SIDEBAR */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}
          android_ripple={{color: '#263353'}}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <Text style={styles.headerTitle}>
          Queue
        </Text>


        {/* SEARCH */}

        <Pressable
          style={styles.searchButton}
          android_ripple={{color: '#263353'}}>

          <Text style={styles.searchIcon}>
            ⌕
          </Text>

        </Pressable>


        {/* MORE */}

        <Pressable
          style={styles.moreTopButton}
          android_ripple={{color: '#263353'}}>

          <Text style={styles.moreTopIcon}>
            ⋮
          </Text>

        </Pressable>

      </View>


      {/* =========================================================
          EMPTY QUEUE
          ========================================================= */}

      <View style={styles.emptyContainer}>

        <Text style={styles.emptyIcon}>
          ♪
        </Text>

        <Text style={styles.emptyTitle}>
          Your queue is empty
        </Text>

        <Text style={styles.emptySubtitle}>
          Songs you add to the queue will appear here
        </Text>

      </View>


      {/* =========================================================
          MINI PLAYER

          IMPORTANT:
          The WHOLE bar opens PlayerScreen.
          The individual playback controls stop the press from
          propagating to the parent.
          ========================================================= */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}
        android_ripple={{color: '#263A60'}}
        accessibilityRole="button"
        accessibilityLabel="Open player">

        {/* =====================================================
            ARTWORK / SONG INFORMATION AREA
            ===================================================== */}

        <View style={styles.miniSpacer} />


        {/* =====================================================
            PREVIOUS
            ===================================================== */}

        <Pressable
          style={styles.miniButton}
          disabled
          onPress={event => {
            event.stopPropagation();
          }}>

          <Text style={styles.previousIcon}>
            |◀
          </Text>

        </Pressable>


        {/* =====================================================
            PLAY
            ===================================================== */}

        <Pressable
          style={styles.playButton}
          onPress={event => {
            event.stopPropagation();
            onPlayerPress();
          }}
          android_ripple={{color: '#687CF5'}}>

          <Text style={styles.playIcon}>
            ▶
          </Text>

        </Pressable>


        {/* =====================================================
            NEXT
            ===================================================== */}

        <Pressable
          style={styles.miniButton}
          disabled
          onPress={event => {
            event.stopPropagation();
          }}>

          <Text style={styles.nextIcon}>
            ▶|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


const styles = StyleSheet.create({

  /* =========================================================
     CONTAINER
     ========================================================= */

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 82,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 14,

    paddingTop: 10,
  },


  /* =========================================================
     MENU
     ========================================================= */

  menuButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 4,
  },


  menuLine: {
    width: 27,
    height: 2.5,

    backgroundColor: '#C9D0DE',

    marginVertical: 3,

    borderRadius: 2,
  },


  /* =========================================================
     TITLE
     ========================================================= */

  headerTitle: {
    flex: 1,

    color: '#F4F5F8',

    fontSize: 24,

    fontWeight: '700',

    marginLeft: 4,
  },


  /* =========================================================
     SEARCH
     ========================================================= */

  searchButton: {
    width: 44,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D6DCE8',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -5,
  },


  /* =========================================================
     MORE
     ========================================================= */

  moreTopButton: {
    width: 38,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  moreTopIcon: {
    color: '#C7CEDC',

    fontSize: 27,

    fontWeight: '700',

    marginTop: -4,
  },


  /* =========================================================
     EMPTY QUEUE
     ========================================================= */

  emptyContainer: {
    flex: 1,

    alignItems: 'center',
    justifyContent: 'center',

    paddingHorizontal: 40,

    /*
      Leave enough visual space above the mini-player.
    */
    paddingBottom: 80,
  },


  emptyIcon: {
    color: '#3C4866',

    fontSize: 52,

    fontWeight: '300',

    marginBottom: 14,
  },


  emptyTitle: {
    color: '#DCE1EB',

    fontSize: 19,

    fontWeight: '700',

    marginBottom: 7,
  },


  emptySubtitle: {
    color: '#727D93',

    fontSize: 13,

    fontWeight: '500',

    textAlign: 'center',

    lineHeight: 19,

    maxWidth: 260,
  },


  /* =========================================================
     MINI PLAYER
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 62,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 8,

    elevation: 8,

    /*
      Important on Android:
      this gives the Pressable an actual elevated touch target.
    */
    overflow: 'hidden',
  },


  /* =========================================================
     EMPTY ARTWORK / SONG AREA
     ========================================================= */

  miniSpacer: {
    flex: 1,
  },


  /* =========================================================
     MINI PLAYER CONTROLS
     ========================================================= */

  miniButton: {
    width: 48,
    height: 60,

    alignItems: 'center',
    justifyContent: 'center',
  },


  previousIcon: {
    color: '#EEF1F6',

    fontSize: 21,

    fontWeight: '600',
  },


  nextIcon: {
    color: '#EEF1F6',

    fontSize: 21,

    fontWeight: '600',
  },


  playButton: {
    width: 54,
    height: 54,

    borderRadius: 27,

    alignItems: 'center',
    justifyContent: 'center',

    backgroundColor: '#5369F2',

    marginHorizontal: 3,
  },


  playIcon: {
    color: '#FFFFFF',

    fontSize: 20,

    marginLeft: 3,
  },

});

export default QueueScreen;