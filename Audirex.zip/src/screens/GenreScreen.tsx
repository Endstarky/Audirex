import React from 'react';
import {
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';


/* =============================================================
   PROPS
   ============================================================= */

type GenreScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};


/* =============================================================
   GENRE DATA
   ============================================================= */

const genres = [
  {
    name: 'Phonk',
    tracks: 34,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'EDM',
    tracks: 28,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Pop',
    tracks: 42,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Hip-Hop',
    tracks: 31,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Rock',
    tracks: 24,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'R&B',
    tracks: 19,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Lo-fi',
    tracks: 37,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Electronic',
    tracks: 26,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Classical',
    tracks: 16,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Indie',
    tracks: 22,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Metal',
    tracks: 14,
    image: require('../../assets/starlight.jpg'),
  },

  {
    name: 'Soundtracks',
    tracks: 18,
    image: require('../../assets/starlight.jpg'),
  },
];


/* =============================================================
   COMPONENT
   ============================================================= */

const GenreScreen = ({
  onMenuPress,
  onPlayerPress,
}: GenreScreenProps) => {

  return (

    <SafeAreaView style={styles.container}>


      {/* =======================================================
          HEADER
          ======================================================= */}

      <View style={styles.header}>


        {/* MENU */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}>

          <View style={styles.menuLine} />

          <View style={styles.menuLine} />

          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <Text style={styles.headerTitle}>
          Genres
        </Text>


        {/* SEARCH */}

        <Pressable style={styles.searchButton}>

          <Text style={styles.searchIcon}>
            ⌕
          </Text>

        </Pressable>


        {/* MORE */}

        <Pressable style={styles.moreHeaderButton}>

          <Text style={styles.moreHeaderIcon}>
            ⋮
          </Text>

        </Pressable>

      </View>


      {/* =======================================================
          GENRE GRID
          ======================================================= */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>


        <View style={styles.genreGrid}>

          {genres.map((genre, index) => (

            <Pressable
              key={`${genre.name}-${index}`}
              style={styles.genreCard}>


              {/* =================================================
                  ARTWORK
                  ================================================= */}

              <View style={styles.genreArtwork}>

                <Image
                  source={genre.image}
                  style={styles.genreImage}
                  resizeMode="cover"
                />


                {/* PLAY BUTTON */}

                <Pressable
                  style={styles.playButton}>

                  <Text style={styles.playIcon}>
                    ▶
                  </Text>

                </Pressable>

              </View>


              {/* =================================================
                  INFORMATION
                  ================================================= */}

              <View style={styles.genreInfo}>

                <Text
                  style={styles.genreName}
                  numberOfLines={1}>

                  {genre.name}

                </Text>


                <Text
                  style={styles.genreTracks}
                  numberOfLines={1}>

                  Tracks: {genre.tracks}

                </Text>


                {/* MORE */}

                <Pressable style={styles.moreButton}>

                  <Text style={styles.moreIcon}>
                    ⋮
                  </Text>

                </Pressable>

              </View>

            </Pressable>

          ))}

        </View>

      </ScrollView>


      {/* =======================================================
          MINI PLAYER
          ======================================================= */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}>


        {/* ARTWORK */}

        <View style={styles.miniArtwork}>

          <Image
            source={require('../../assets/starlight.jpg')}
            style={styles.miniArtworkImage}
            resizeMode="cover"
          />

        </View>


        {/* SONG INFORMATION */}

        <View style={styles.miniInfo}>

          <Text
            style={styles.miniTitle}
            numberOfLines={1}>

            Starlight

          </Text>


          <Text
            style={styles.miniArtist}
            numberOfLines={1}>

            The Weeknd

          </Text>

        </View>


        {/* PAUSE */}

        <Pressable
          style={styles.miniButton}>

          <Text style={styles.miniPause}>
            Ⅱ
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable
          style={styles.miniButton}>

          <Text style={styles.miniNext}>
            ▷|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


/* =============================================================
   STYLES
   ============================================================= */

const styles = StyleSheet.create({

  /* ===========================================================
     CONTAINER
     =========================================================== */

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* ===========================================================
     HEADER
     =========================================================== */

  header: {
    height: 82,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 12,

    paddingTop: 8,
  },


  menuButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 5,
  },


  menuLine: {
    width: 28,
    height: 2.5,

    backgroundColor: '#C9D0DE',

    marginVertical: 3,

    borderRadius: 2,
  },


  headerTitle: {
    flex: 1,

    color: '#F3F4F8',

    fontSize: 24,

    fontWeight: '700',

    marginLeft: 4,
  },


  searchButton: {
    width: 45,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D6DCE8',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -5,
  },


  moreHeaderButton: {
    width: 35,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  moreHeaderIcon: {
    color: '#C7CEDB',

    fontSize: 28,

    fontWeight: '700',

    marginTop: -5,
  },


  /* ===========================================================
     SCROLL
     =========================================================== */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 10,

    paddingTop: 5,

    paddingBottom: 155,
  },


  /* ===========================================================
     GRID
     =========================================================== */

  genreGrid: {
    flexDirection: 'row',

    flexWrap: 'wrap',

    justifyContent: 'space-between',
  },


  /* ===========================================================
     GENRE CARD
     =========================================================== */

  genreCard: {
    width: '31.8%',

    borderRadius: 10,

    overflow: 'hidden',

    backgroundColor: '#111126',

    marginBottom: 12,
  },


  /* ===========================================================
     GENRE ARTWORK
     =========================================================== */

  genreArtwork: {
    width: '100%',

    aspectRatio: 1,

    backgroundColor: '#09090D',

    position: 'relative',

    overflow: 'hidden',
  },


  genreImage: {
    width: '100%',

    height: '100%',
  },


  /* ===========================================================
     PLAY BUTTON
     =========================================================== */

  playButton: {
    position: 'absolute',

    right: 8,

    bottom: 8,

    width: 38,

    height: 38,

    borderRadius: 19,

    backgroundColor: '#F3F4F7',

    alignItems: 'center',

    justifyContent: 'center',

    elevation: 4,
  },


  playIcon: {
    color: '#343743',

    fontSize: 15,

    marginLeft: 2,
  },


  /* ===========================================================
     GENRE INFORMATION
     =========================================================== */

  genreInfo: {
    minHeight: 74,

    paddingHorizontal: 8,

    paddingTop: 9,

    paddingBottom: 7,

    position: 'relative',
  },


  genreName: {
    color: '#F0F1F5',

    fontSize: 15,

    fontWeight: '700',

    paddingRight: 20,
  },


  genreTracks: {
    color: '#81899C',

    fontSize: 11,

    marginTop: 5,

    paddingRight: 20,
  },


  /* ===========================================================
     MORE BUTTON
     =========================================================== */

  moreButton: {
    position: 'absolute',

    right: 1,

    bottom: 4,

    width: 30,

    height: 42,

    alignItems: 'center',

    justifyContent: 'center',
  },


  moreIcon: {
    color: '#9AA3B5',

    fontSize: 23,

    fontWeight: '700',
  },


  /* ===========================================================
     MINI PLAYER
     =========================================================== */

  miniPlayer: {
    position: 'absolute',

    left: 10,

    right: 10,

    bottom: 72,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 10,

    elevation: 8,
  },


  miniArtwork: {
    width: 52,

    height: 52,

    borderRadius: 9,

    overflow: 'hidden',

    backgroundColor: '#10284B',
  },


  miniArtworkImage: {
    width: '100%',

    height: '100%',
  },


  miniInfo: {
    flex: 1,

    marginLeft: 12,

    justifyContent: 'center',
  },


  miniTitle: {
    color: '#EEF0F5',

    fontSize: 14,

    fontWeight: '700',
  },


  miniArtist: {
    color: '#808BA0',

    fontSize: 11,

    marginTop: 3,
  },


  miniButton: {
    width: 46,

    height: 58,

    alignItems: 'center',

    justifyContent: 'center',
  },


  miniPause: {
    color: '#F1F3F7',

    fontSize: 22,

    fontWeight: '600',
  },


  miniNext: {
    color: '#F1F3F7',

    fontSize: 22,
  },

});


export default GenreScreen;