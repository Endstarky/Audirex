import React, {useEffect, useRef, useState} from 'react';
import {
  ActivityIndicator,
  Animated,
  Easing,
  Keyboard,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  getLocalSongs,
  LocalSong,
  requestMusicPermission,
} from '../services/localMusic';

type DiscoverScreenProps = {
  onBack: () => void;
};

const DiscoverScreen = ({onBack}: DiscoverScreenProps) => {
  const [searchText, setSearchText] = useState('');
  const [results, setResults] = useState<LocalSong[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');

  // Store the actual native TextInput instance without
  // forcing the problematic TextInputType TypeScript type.
  const searchInput = useRef<any>(null);

  /*
   * Small focus movement only.
   *
   * This is deliberately NOT a screen transition.
   */
  const focusAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(focusAnim, {
      toValue: 1,
      duration: 180,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();

    const timer = setTimeout(() => {
      searchInput.current?.focus();
    }, 100);

    return () => clearTimeout(timer);
  }, [focusAnim]);

  const handleBack = () => {
    Keyboard.dismiss();

    Animated.timing(focusAnim, {
      toValue: 0,
      duration: 120,
      easing: Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      onBack();
    });
  };

  const hasSearch = searchText.trim().length > 0;

  useEffect(() => {
    const query = searchText.trim();
    if (!query) {
      setResults([]);
      setSearchError('');
      setIsSearching(false);
      return;
    }

    let isCurrent = true;
    const timer = setTimeout(async () => {
      setIsSearching(true);
      setSearchError('');
      try {
        const granted = await requestMusicPermission();
        const songs = granted ? await getLocalSongs(query) : [];
        if (isCurrent) {
          setResults(songs);
          if (!granted) {
            setSearchError('Allow music access to search your library.');
          }
        }
      } catch {
        if (isCurrent) {
          setResults([]);
          setSearchError('Your music library could not be searched.');
        }
      } finally {
        if (isCurrent) {
          setIsSearching(false);
        }
      }
    }, 250);

    return () => {
      isCurrent = false;
      clearTimeout(timer);
    };
  }, [searchText]);

  return (
    <View style={styles.container}>

      <StatusBar barStyle="light-content" />

      {/* =====================================================
          SEARCH AREA
          ===================================================== */}

      <Animated.View
        style={[
          styles.searchArea,
          {
            transform: [
              {
                translateY: focusAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [24, 0],
                }),
              },
            ],
          },
        ]}>

        {/* =====================================================
            SEARCH BAR
            ===================================================== */}

        <View style={styles.searchBar}>

          {/* BACK */}

          <TouchableOpacity
            style={styles.backButton}
            activeOpacity={0.7}
            onPress={handleBack}>

            <Text style={styles.backIcon}>
              ‹
            </Text>

          </TouchableOpacity>


          {/* SEARCH ICON */}

          <Text style={styles.searchIcon}>
            ⌕
          </Text>


          {/* SEARCH INPUT */}

          <TextInput
            ref={instance => {
              searchInput.current = instance;
            }}
            value={searchText}
            onChangeText={setSearchText}
            placeholder="Search songs, artists, albums..."
            placeholderTextColor="#7B8497"
            style={styles.searchInput}
            autoFocus={false}
            returnKeyType="search"
            selectionColor="#5369FF"
            cursorColor="#5369FF"
          />


          {/* CLEAR */}

          {searchText.length > 0 && (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => {
                setSearchText('');
                searchInput.current?.focus();
              }}>

              <Text style={styles.clearIcon}>
                ×
              </Text>

            </TouchableOpacity>
          )}

        </View>


        {/* =====================================================
            CONTENT
            ===================================================== */}

        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.content}>

          {!hasSearch ? (

            /* =================================================
               RECENT SEARCHES
               ================================================= */

            <View>

              <View style={styles.sectionHeader}>

                <Text style={styles.sectionTitle}>
                  Recent searches
                </Text>

                <TouchableOpacity activeOpacity={0.7}>
                  <Text style={styles.clearText}>
                    Clear
                  </Text>
                </TouchableOpacity>

              </View>


              {/* RECENT SEARCH 1 */}

              <TouchableOpacity
                style={styles.recentSearch}
                activeOpacity={0.7}
                onPress={() => {
                  setSearchText('As It Was');
                }}>

                <Text style={styles.historyIcon}>
                  ↶
                </Text>

                <Text style={styles.recentText}>
                  As It Was
                </Text>

              </TouchableOpacity>


              {/* RECENT SEARCH 2 */}

              <TouchableOpacity
                style={styles.recentSearch}
                activeOpacity={0.7}
                onPress={() => {
                  setSearchText('Flowers');
                }}>

                <Text style={styles.historyIcon}>
                  ↶
                </Text>

                <Text style={styles.recentText}>
                  Flowers
                </Text>

              </TouchableOpacity>


              {/* RECENT SEARCH 3 */}

              <TouchableOpacity
                style={styles.recentSearch}
                activeOpacity={0.7}
                onPress={() => {
                  setSearchText('Blinding Lights');
                }}>

                <Text style={styles.historyIcon}>
                  ↶
                </Text>

                <Text style={styles.recentText}>
                  Blinding Lights
                </Text>

              </TouchableOpacity>

            </View>

          ) : (

            /* =================================================
               SEARCH RESULTS
               ================================================= */

            <View>

              <View style={styles.sectionHeader}>

                <Text style={styles.sectionTitle}>
                  Search results
                </Text>

              </View>


              <Text style={styles.subSectionTitle}>
                Songs on this device
              </Text>

              {isSearching && <ActivityIndicator color="#5369FF" />}

              {!isSearching && searchError.length > 0 && (
                <Text style={styles.emptyResults}>{searchError}</Text>
              )}

              {!isSearching && !searchError && results.length === 0 && (
                <Text style={styles.emptyResults}>
                  No songs found in your library.
                </Text>
              )}

              {results.map(song => (
                <TouchableOpacity
                  key={song.id}
                  style={styles.songRow}
                  activeOpacity={0.7}>
                  <View style={styles.songArtwork}>
                    <View style={styles.artworkRing} />
                  </View>
                  <View style={styles.songInfo}>
                    <Text style={styles.songTitle} numberOfLines={1}>
                      {song.title}
                    </Text>
                    <Text style={styles.artist} numberOfLines={1}>
                      {song.artist} - {song.album}
                    </Text>
                  </View>
                  <Text style={styles.moreIcon}>...</Text>
                </TouchableOpacity>
              ))}


              {false && (
              <>
              <TouchableOpacity
                style={styles.songRow}
                activeOpacity={0.7}>

                <View style={styles.songArtwork}>
                  <View style={styles.artworkRing} />
                </View>


                <View style={styles.songInfo}>

                  <Text style={styles.songTitle}>
                    Blinding Lights
                  </Text>

                  <Text style={styles.artist}>
                    The Weeknd
                  </Text>

                </View>


                <Text style={styles.moreIcon}>
                  ⋮
                </Text>

              </TouchableOpacity>


              <TouchableOpacity
                style={styles.songRow}
                activeOpacity={0.7}>

                <View style={styles.songArtwork}>
                  <View style={styles.artworkRing} />
                </View>


                <View style={styles.songInfo}>

                  <Text style={styles.songTitle}>
                    Cruel Summer
                  </Text>

                  <Text style={styles.artist}>
                    Taylor Swift
                  </Text>

                </View>


                <Text style={styles.moreIcon}>
                  ⋮
                </Text>

              </TouchableOpacity>


              </>
              )}

              {/* YOU MIGHT LIKE */}

              <Text style={styles.subSectionTitle}>
                You might like
              </Text>


              <View style={styles.recommendationRow}>

                <TouchableOpacity
                  style={styles.recommendationCard}
                  activeOpacity={0.8}>

                  <View style={styles.recommendationArtwork}>
                    <View style={styles.smallArtworkRing} />
                  </View>

                  <View style={styles.recommendationInfo}>

                    <Text style={styles.recommendationTitle}>
                      The Weeknd
                    </Text>

                    <Text style={styles.recommendationType}>
                      Artist
                    </Text>

                  </View>

                </TouchableOpacity>


                <TouchableOpacity
                  style={styles.recommendationCard}
                  activeOpacity={0.8}>

                  <View style={styles.recommendationArtwork}>
                    <View style={styles.smallArtworkRing} />
                  </View>

                  <View style={styles.recommendationInfo}>

                    <Text style={styles.recommendationTitle}>
                      Moonlit Drive
                    </Text>

                    <Text style={styles.recommendationType}>
                      Album
                    </Text>

                  </View>

                </TouchableOpacity>

              </View>


              {/* GENRES */}

              <Text style={styles.subSectionTitle}>
                Browse genres
              </Text>


              <View style={styles.genreRow}>

                <TouchableOpacity style={styles.genreCard}>
                  <Text style={styles.genreText}>
                    Pop
                  </Text>
                </TouchableOpacity>


                <TouchableOpacity style={styles.genreCard}>
                  <Text style={styles.genreText}>
                    Hip-Hop
                  </Text>
                </TouchableOpacity>


                <TouchableOpacity style={styles.genreCard}>
                  <Text style={styles.genreText}>
                    Electronic
                  </Text>
                </TouchableOpacity>

              </View>

            </View>

          )}

        </ScrollView>

      </Animated.View>


      {/* =====================================================
          MINI PLAYER

          It stays fixed.

          Android keyboard will cover it.
          It does NOT move upward.
          ===================================================== */}

      <View style={styles.player}>

        <View style={styles.playerArtwork}>

          <View style={styles.playerArtworkRing} />

        </View>


        <View style={styles.playerInfo}>

          <Text style={styles.playerTitle}>
            Starlight
          </Text>

          <Text style={styles.playerArtist}>
            The Weeknd
          </Text>

        </View>


        <TouchableOpacity
          style={styles.playerButton}
          activeOpacity={0.7}>

          <Text style={styles.pauseIcon}>
            ❚❚
          </Text>

        </TouchableOpacity>


        <TouchableOpacity
          style={styles.playerButton}
          activeOpacity={0.7}>

          <Text style={styles.nextIcon}>
            ▷|
          </Text>

        </TouchableOpacity>

      </View>

    </View>
  );
};


const styles = StyleSheet.create({

  /* =====================================================
     CONTAINER
     ===================================================== */

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* =====================================================
     SEARCH AREA
     ===================================================== */

  searchArea: {
    flex: 1,
  },


  /* =====================================================
     SEARCH BAR
     ===================================================== */

  searchBar: {
    height: 50,

    marginTop: (StatusBar.currentHeight || 24) + 8,

    marginHorizontal: 8,

    borderRadius: 12,

    backgroundColor: '#07182E',

    borderWidth: 1,

    borderColor: '#17304F',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 5,
  },


  backButton: {
    width: 38,

    height: 42,

    alignItems: 'center',

    justifyContent: 'center',
  },


  backIcon: {
    color: '#E9EDF5',

    fontSize: 31,

    fontWeight: '300',

    lineHeight: 34,
  },


  searchIcon: {
    color: '#8290A7',

    fontSize: 22,

    marginRight: 7,
  },


  searchInput: {
    flex: 1,

    color: '#E9EDF5',

    fontSize: 11,

    paddingVertical: 0,

    height: 45,
  },


  clearIcon: {
    color: '#9CA6B8',

    fontSize: 24,

    fontWeight: '300',

    paddingHorizontal: 8,
  },


  /* =====================================================
     CONTENT
     ===================================================== */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 12,

    paddingTop: 18,

    paddingBottom: 100,
  },


  /* =====================================================
     SECTION HEADER
     ===================================================== */

  sectionHeader: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    marginBottom: 12,
  },


  sectionTitle: {
    color: '#F4F6FA',

    fontSize: 16,

    fontWeight: '700',
  },


  clearText: {
    color: '#279BFF',

    fontSize: 10,
  },


  subSectionTitle: {
    color: '#F4F6FA',

    fontSize: 15,

    fontWeight: '700',

    marginTop: 22,

    marginBottom: 11,
  },


  /* =====================================================
     RECENT SEARCHES
     ===================================================== */

  recentSearch: {
    height: 42,

    flexDirection: 'row',

    alignItems: 'center',

    borderRadius: 8,

    paddingHorizontal: 4,

    marginBottom: 3,
  },


  historyIcon: {
    color: '#647188',

    fontSize: 18,

    width: 30,
  },


  recentText: {
    color: '#9AA3B5',

    fontSize: 11,
  },


  /* =====================================================
     SONG RESULTS
     ===================================================== */

  songRow: {
    height: 60,

    flexDirection: 'row',

    alignItems: 'center',

    marginBottom: 8,
  },


  songArtwork: {
    width: 52,

    height: 52,

    borderRadius: 7,

    backgroundColor: '#182545',

    alignItems: 'center',

    justifyContent: 'center',
  },


  artworkRing: {
    width: 27,

    height: 27,

    borderRadius: 14,

    borderWidth: 2,

    borderColor: '#2860DF',
  },


  songInfo: {
    flex: 1,

    marginLeft: 10,
  },


  songTitle: {
    color: '#F0F2F6',

    fontSize: 11,

    fontWeight: '600',
  },


  artist: {
    color: '#737D92',

    fontSize: 9,

    marginTop: 3,
  },

  emptyResults: {
    color: '#9AA3B5',
    fontSize: 11,
    marginBottom: 12,
  },


  moreIcon: {
    color: '#7E899D',

    fontSize: 22,

    paddingHorizontal: 5,
  },


  /* =====================================================
     RECOMMENDATIONS
     ===================================================== */

  recommendationRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',
  },


  recommendationCard: {
    width: '48.5%',

    height: 58,

    borderRadius: 9,

    backgroundColor: '#151F35',

    flexDirection: 'row',

    alignItems: 'center',

    overflow: 'hidden',
  },


  recommendationArtwork: {
    width: 52,

    height: '100%',

    backgroundColor: '#102B48',

    alignItems: 'center',

    justifyContent: 'center',
  },


  smallArtworkRing: {
    width: 25,

    height: 25,

    borderRadius: 13,

    borderWidth: 1.5,

    borderColor: '#2860DF',
  },


  recommendationInfo: {
    flex: 1,

    marginLeft: 7,
  },


  recommendationTitle: {
    color: '#E7EAF0',

    fontSize: 9,

    fontWeight: '600',
  },


  recommendationType: {
    color: '#737D92',

    fontSize: 8,

    marginTop: 2,
  },


  /* =====================================================
     GENRES
     ===================================================== */

  genreRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',
  },


  genreCard: {
    width: '31.5%',

    height: 44,

    borderRadius: 8,

    backgroundColor: '#182A45',

    alignItems: 'flex-start',

    justifyContent: 'center',

    paddingHorizontal: 12,
  },


  genreText: {
    color: '#E8EBF2',

    fontSize: 10,

    fontWeight: '600',
  },


  /* =====================================================
     MINI PLAYER
     ===================================================== */

  player: {
    position: 'absolute',

    left: 8,

    right: 8,

    bottom: 32,

    height: 62,

    borderRadius: 10,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 9,
  },


  playerArtwork: {
    width: 44,

    height: 44,

    borderRadius: 8,

    backgroundColor: '#10284B',

    alignItems: 'center',

    justifyContent: 'center',
  },


  playerArtworkRing: {
    width: 21,

    height: 21,

    borderRadius: 11,

    borderWidth: 1.5,

    borderColor: '#2860DF',
  },


  playerInfo: {
    flex: 1,

    marginLeft: 10,
  },


  playerTitle: {
    color: '#E8EBF2',

    fontSize: 11,

    fontWeight: '600',
  },


  playerArtist: {
    color: '#778196',

    fontSize: 9,

    marginTop: 2,
  },


  playerButton: {
    width: 38,

    height: 48,

    alignItems: 'center',

    justifyContent: 'center',
  },


  pauseIcon: {
    color: '#E9ECF3',

    fontSize: 19,

    fontWeight: '600',
  },


  nextIcon: {
    color: '#E9ECF3',

    fontSize: 20,
  },

});


export default DiscoverScreen;
