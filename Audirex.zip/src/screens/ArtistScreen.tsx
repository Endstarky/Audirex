import React from 'react';
import {
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type ArtistScreenProps = {
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

const ArtistScreen = ({
  onMenuPress,
  onPlayerPress,
}: ArtistScreenProps) => {

  const artists = [
    {
      name: 'Unknown Artist',
      albums: 0,
      tracks: 26,
      image: require('../../assets/starlight.jpg'),
    },
    {
      name: '.ashade',
      albums: 1,
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      name: '031974_30',
      albums: 0,
      tracks: 1,
      image: require('../../assets/starlight.jpg'),
    },
    {
      name: 'THIRST',
      albums: 2,
      tracks: 4,
      image: require('../../assets/starlight.jpg'),
    },
    {
      name: 'mell-ø',
      albums: 3,
      tracks: 8,
      image: require('../../assets/starlight.jpg'),
    },
    {
      name: 'The Weeknd',
      albums: 4,
      tracks: 18,
      image: require('../../assets/starlight.jpg'),
    },
  ];

  return (
    <SafeAreaView style={styles.container}>

      {/* =====================================================
          HEADER
          ===================================================== */}

      <View style={styles.header}>

        {/* SIDEBAR */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}
          android_ripple={{
            color: '#182744',
            borderless: true,
          }}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <Text style={styles.headerTitle}>
          Artists
        </Text>


        <View style={styles.headerActions}>

          {/* SEARCH */}

          <Pressable style={styles.headerButton}>

            <Text style={styles.searchIcon}>
              ⌕
            </Text>

          </Pressable>


          {/* MORE */}

          <Pressable style={styles.headerButton}>

            <Text style={styles.headerMore}>
              ⋮
            </Text>

          </Pressable>

        </View>

      </View>


      {/* =====================================================
          ARTIST LIST
          ===================================================== */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>

        {artists.map((artist, index) => (

          <Pressable
            key={`${artist.name}-${index}`}
            style={styles.artistCard}>

            {/* ARTIST ARTWORK */}

            <View style={styles.artistArtwork}>

              <Image
                source={artist.image}
                style={styles.artistImage}
                resizeMode="cover"
              />


              {/* DARK GRADIENT-LIKE OVERLAY */}

              <View style={styles.artworkShade} />


              {/* PLAY */}

              <Pressable
                style={styles.playButton}
                onPress={() => {}}>

                <Text style={styles.playIcon}>
                  ▶
                </Text>

              </Pressable>

            </View>


            {/* ARTIST INFORMATION */}

            <View style={styles.artistInfo}>

              <View style={styles.artistText}>

                <Text
                  style={styles.artistName}
                  numberOfLines={1}>

                  {artist.name}

                </Text>


                <View style={styles.artistStats}>

                  <Text style={styles.statText}>
                    Albums: {artist.albums}
                  </Text>

                  <Text style={styles.statDivider}>
                    •
                  </Text>

                  <Text style={styles.statText}>
                    Tracks: {artist.tracks}
                  </Text>

                </View>

              </View>


              {/* MORE */}

              <Pressable style={styles.moreButton}>

                <Text style={styles.moreIcon}>
                  ⋮
                </Text>

              </Pressable>

            </View>

          </Pressable>

        ))}

      </ScrollView>


      {/* =====================================================
          MINI PLAYER
          ===================================================== */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}
        android_ripple={{
          color: '#203452',
        }}>

        {/* ARTWORK */}

        <View style={styles.miniArtwork}>

          <Image
            source={require('../../assets/starlight.jpg')}
            style={styles.miniArtworkImage}
            resizeMode="cover"
          />

        </View>


        {/* INFORMATION */}

        <View style={styles.miniInfo}>

          <Text
            style={styles.miniTitle}
            numberOfLines={1}>

            Starlight

          </Text>

          <Text
            style={styles.miniArtist}
            numberOfLines={1}>

            The Weeknd

          </Text>

        </View>


        {/* PAUSE */}

        <Pressable
          style={styles.miniButton}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniPause}>
            Ⅱ
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable
          style={styles.miniButton}
          onPress={(event) => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniNext}>
            ▷|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


/* =============================================================
   STYLES
   ============================================================= */

const styles = StyleSheet.create({

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 82,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 12,

    paddingTop: 10,
  },


  menuButton: {
    width: 50,
    height: 50,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 4,
  },


  menuLine: {
    width: 29,
    height: 2.5,

    backgroundColor: '#C9D1E0',

    marginVertical: 3,

    borderRadius: 2,
  },


  headerTitle: {
    flex: 1,

    color: '#F5F6FA',

    fontSize: 24,

    fontWeight: '700',

    marginLeft: 4,
  },


  headerActions: {
    flexDirection: 'row',

    alignItems: 'center',
  },


  headerButton: {
    width: 45,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D7DDEA',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -4,
  },


  headerMore: {
    color: '#C8D0DE',

    fontSize: 28,

    fontWeight: '700',
  },


  /* =========================================================
     SCROLL
     ========================================================= */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 10,

    paddingTop: 8,

    paddingBottom: 125,
  },


  /* =========================================================
     ARTIST CARD
     ========================================================= */

  artistCard: {
    width: '100%',

    backgroundColor: '#10182A',

    borderRadius: 11,

    overflow: 'hidden',

    marginBottom: 14,
  },


  /* =========================================================
     ARTIST ARTWORK
     ========================================================= */

  artistArtwork: {
    width: '100%',

    height: 205,

    backgroundColor: '#111A2E',

    position: 'relative',
  },


  artistImage: {
    width: '100%',
    height: '100%',
  },


  artworkShade: {
    position: 'absolute',

    left: 0,
    right: 0,
    bottom: 0,

    height: 70,

    backgroundColor: 'rgba(5, 7, 25, 0.28)',
  },


  playButton: {
    position: 'absolute',

    right: 13,
    bottom: 12,

    width: 42,
    height: 42,

    borderRadius: 21,

    backgroundColor: '#F2F4F8',

    alignItems: 'center',
    justifyContent: 'center',

    elevation: 5,
  },


  playIcon: {
    color: '#20283A',

    fontSize: 16,

    marginLeft: 2,
  },


  /* =========================================================
     ARTIST INFORMATION
     ========================================================= */

  artistInfo: {
    minHeight: 72,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 14,
  },


  artistText: {
    flex: 1,
  },


  artistName: {
    color: '#EEF1F6',

    fontSize: 18,

    fontWeight: '700',
  },


  artistStats: {
    flexDirection: 'row',

    alignItems: 'center',

    marginTop: 6,
  },


  statText: {
    color: '#7E899F',

    fontSize: 12,

    fontWeight: '500',
  },


  statDivider: {
    color: '#566176',

    fontSize: 12,

    marginHorizontal: 7,
  },


  moreButton: {
    width: 44,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  moreIcon: {
    color: '#929DB1',

    fontSize: 26,

    fontWeight: '700',
  },


  /* =========================================================
     MINI PLAYER
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 64,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    borderWidth: 1,

    borderColor: '#203453',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 10,

    elevation: 10,
  },


  miniArtwork: {
    width: 52,
    height: 52,

    borderRadius: 9,

    overflow: 'hidden',

    backgroundColor: '#10284B',
  },


  miniArtworkImage: {
    width: '100%',
    height: '100%',
  },


  miniInfo: {
    flex: 1,

    marginLeft: 12,
  },


  miniTitle: {
    color: '#EEF1F6',

    fontSize: 14,

    fontWeight: '700',
  },


  miniArtist: {
    color: '#818CA1',

    fontSize: 11,

    marginTop: 3,
  },


  miniButton: {
    width: 46,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  miniPause: {
    color: '#F2F4F8',

    fontSize: 21,

    fontWeight: '600',
  },


  miniNext: {
    color: '#F2F4F8',

    fontSize: 21,
  },

});

export default ArtistScreen;