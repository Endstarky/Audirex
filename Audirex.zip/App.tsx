import React, {useEffect, useRef, useState} from 'react';
import {
  Animated,
  Dimensions,
  Easing,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import SplashScreen from './src/screens/SplashScreen';
import HomeScreen from './src/screens/HomeScreen';
import DiscoverScreen from './src/screens/DiscoverScreen';
import PlayerScreen from './src/screens/PlayerScreen';
import PlaylistScreen from './src/screens/PlaylistScreen';
import AlbumScreen from './src/screens/AlbumScreen';
import ArtistScreen from './src/screens/ArtistScreen';
import GenreScreen from './src/screens/GenreScreen';
import QueueScreen from './src/screens/QueueScreen';
import AllSongsScreen from './src/screens/AllSongsScreen';
import FolderScreen from './src/screens/FolderScreen';

/* =============================================================
   ICONS
   ============================================================= */

const ICONS = {
  home: require('./assets/icons/home.png'),
  allSongs: require('./assets/icons/allsongs.png'),
  albums: require('./assets/icons/albums.png'),
  artists: require('./assets/icons/artists.png'),
  genres: require('./assets/icons/genre.png'),
  playlists: require('./assets/icons/playlist.png'),
  folders: require('./assets/icons/folders.png'),
  settings: require('./assets/icons/settings.png'),
  equalizer: require('./assets/icons/equalizer-white.png'),
  queue: require('./assets/icons/queue.png'),
};

/* =============================================================
   SCREEN DIMENSIONS
   ============================================================= */

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} =
  Dimensions.get('window');

const DRAWER_WIDTH = Math.min(SCREEN_WIDTH * 0.72, 300);

/* =============================================================
   LIBRARY PAGES
   ============================================================= */

type LibraryPage =
  | 'home'
  | 'allsongs'
  | 'queue'
  | 'playlists'
  | 'albums'
  | 'artists'
  | 'genres'
  | 'folders';

/* =============================================================
   APP
   ============================================================= */

const App = () => {
  /* =========================================================
     SPLASH SCREEN
     ========================================================= */

  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  /* =========================================================
     CURRENT PAGE
     ========================================================= */

  const [currentPage, setCurrentPage] =
    useState<LibraryPage>('home');

  /* =========================================================
     SEARCH
     ========================================================= */

  const [searchOpen, setSearchOpen] = useState(false);

  /* =========================================================
     PLAYER
     ========================================================= */

  const [playerOpen, setPlayerOpen] = useState(false);

  const [playerOrigin, setPlayerOrigin] =
    useState<LibraryPage>('home');

  /* =========================================================
     PLAYER ANIMATION
     ========================================================= */

  const playerY = useRef(
    new Animated.Value(SCREEN_HEIGHT),
  ).current;

  /* =========================================================
     SIDEBAR
     ========================================================= */

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const drawerX = useRef(
    new Animated.Value(-DRAWER_WIDTH),
  ).current;

  const overlayOpacity = useRef(
    new Animated.Value(0),
  ).current;

  /* =========================================================
     OPEN SIDEBAR
     ========================================================= */

  const openSidebar = () => {
    setSidebarOpen(true);

    Animated.parallel([
      Animated.timing(drawerX, {
        toValue: 0,
        duration: 280,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),

      Animated.timing(overlayOpacity, {
        toValue: 1,
        duration: 250,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  };

  /* =========================================================
     CLOSE SIDEBAR
     ========================================================= */

  const closeSidebar = () => {
    Animated.parallel([
      Animated.timing(drawerX, {
        toValue: -DRAWER_WIDTH,
        duration: 230,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: true,
      }),

      Animated.timing(overlayOpacity, {
        toValue: 0,
        duration: 200,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start(() => {
      setSidebarOpen(false);
    });
  };

  /* =========================================================
     MENU BUTTON
     ========================================================= */

  const handleMenuPress = () => {
    if (sidebarOpen) {
      closeSidebar();
      return;
    }

    if (searchOpen) {
      setSearchOpen(false);
    }

    if (playerOpen) {
      Animated.timing(playerY, {
        toValue: SCREEN_HEIGHT,
        duration: 240,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: true,
      }).start(() => {
        setPlayerOpen(false);
        openSidebar();
      });

      return;
    }

    openSidebar();
  };

  /* =========================================================
     SEARCH
     ========================================================= */

  const handleSearchPress = () => {
    if (playerOpen) {
      Animated.timing(playerY, {
        toValue: SCREEN_HEIGHT,
        duration: 220,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: true,
      }).start(() => {
        setPlayerOpen(false);
      });
    }

    setSearchOpen(true);
  };

  const handleSearchBack = () => {
    setSearchOpen(false);
  };

  /* =========================================================
     PLAYER - OPEN
     ========================================================= */

  const handlePlayerPress = () => {
    setPlayerOrigin(currentPage);

    setSearchOpen(false);

    if (sidebarOpen) {
      closeSidebar();
    }

    playerY.setValue(SCREEN_HEIGHT);

    setPlayerOpen(true);

    requestAnimationFrame(() => {
      Animated.timing(playerY, {
        toValue: 0,
        duration: 360,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
    });
  };

  /* =========================================================
     PLAYER - CLOSE
     ========================================================= */

  const handlePlayerBack = () => {
    Animated.timing(playerY, {
      toValue: SCREEN_HEIGHT,
      duration: 300,
      easing: Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      setPlayerOpen(false);
      setCurrentPage(playerOrigin);
      playerY.setValue(SCREEN_HEIGHT);
    });
  };

  /* =========================================================
     SIDEBAR NAVIGATION
     ========================================================= */

  const handleDrawerItemPress = (item: string) => {
    closeSidebar();

    if (item === 'Home') {
      setCurrentPage('home');
      return;
    }

    if (item === 'All Songs') {
      setCurrentPage('allsongs');
      return;
    }

    if (item === 'Queue') {
      setCurrentPage('queue');
      return;
    }

    if (item === 'Playlists') {
      setCurrentPage('playlists');
      return;
    }

    if (item === 'Albums') {
      setCurrentPage('albums');
      return;
    }

    if (item === 'Artists') {
      setCurrentPage('artists');
      return;
    }

    if (item === 'Genres') {
      setCurrentPage('genres');
      return;
    }

    if (item === 'Folders') {
      setCurrentPage('folders');
      return;
    }

    if (item === 'Settings') {
      console.log('Settings screen not created yet');
      return;
    }

    if (item === 'Equalizer') {
      console.log('Equalizer screen not created yet');
      return;
    }
  };

  /* =========================================================
     SPLASH
     ========================================================= */

  if (showSplash) {
    return <SplashScreen />;
  }

  /* =========================================================
     MAIN APP
     ========================================================= */

  return (
    <View style={styles.container}>

      {/* =====================================================
          HOME
          ===================================================== */}

      {currentPage === 'home' && (
        <HomeScreen
          onSearchPress={handleSearchPress}
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          ALL SONGS
          ===================================================== */}

      {currentPage === 'allsongs' && (
        <AllSongsScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          QUEUE
          ===================================================== */}

      {currentPage === 'queue' && (
        <QueueScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          PLAYLISTS
          ===================================================== */}

      {currentPage === 'playlists' && (
        <PlaylistScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {/* =====================================================
          ALBUMS
          ===================================================== */}

      {currentPage === 'albums' && (
        <AlbumScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          ARTISTS
          ===================================================== */}

      {currentPage === 'artists' && (
        <ArtistScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          GENRES
          ===================================================== */}

      {currentPage === 'genres' && (
        <GenreScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          FOLDERS
          ===================================================== */}

      {currentPage === 'folders' && (
        <FolderScreen
          onMenuPress={handleMenuPress}
          onPlayerPress={handlePlayerPress}
        />
      )}

      {/* =====================================================
          SEARCH / DISCOVER
          ===================================================== */}

      {searchOpen && (
        <View style={styles.searchOverlay}>
          <DiscoverScreen onBack={handleSearchBack} />
        </View>
      )}

      {/* =====================================================
          GLOBAL PLAYER
          ===================================================== */}

      {playerOpen && (
        <Animated.View
          style={[
            styles.playerOverlay,
            {
              transform: [
                {
                  translateY: playerY,
                },
              ],
            },
          ]}>

          <PlayerScreen
            onBack={handlePlayerBack}
          />

        </Animated.View>
      )}

      {/* =====================================================
          GLOBAL SIDEBAR
          ===================================================== */}

      {sidebarOpen && (
        <View
          style={styles.sidebarLayer}
          pointerEvents="box-none">

          {/* =================================================
              BACKGROUND DIMMING
              ================================================= */}

          <Animated.View
            pointerEvents="none"
            style={[
              styles.backgroundOverlay,
              {
                opacity: overlayOpacity,
              },
            ]}
          />

          {/* =================================================
              TAP OUTSIDE TO CLOSE
              ================================================= */}

          <Pressable
            style={[
              styles.outsidePress,
              {
                left: DRAWER_WIDTH,
              },
            ]}
            onPress={closeSidebar}
          />

          {/* =================================================
              DRAWER
              ================================================= */}

          <Animated.View
            style={[
              styles.drawer,
              {
                width: DRAWER_WIDTH,

                transform: [
                  {
                    translateX: drawerX,
                  },
                ],
              },
            ]}>

            {/* ===============================================
                DRAWER HEADER
                =============================================== */}

            <View style={styles.drawerTop}>

              <View style={styles.logoBox}>
                <Text style={styles.logoText}>
                  ♫
                </Text>
              </View>

              <TouchableOpacity
                style={styles.closeButton}
                activeOpacity={0.7}
                onPress={closeSidebar}>

                <Text style={styles.closeText}>
                  ×
                </Text>

              </TouchableOpacity>

            </View>

            {/* ===============================================
                MAIN MENU
                =============================================== */}

            <View style={styles.navigation}>

              {/* HOME */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'home' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Home')
                }>

                <Image
                  source={ICONS.home}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'home' &&
                      styles.selectedText,
                  ]}>
                  Home
                </Text>

              </TouchableOpacity>

              {/* ALL SONGS */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'allsongs' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('All Songs')
                }>

                <Image
                  source={ICONS.allSongs}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'allsongs' &&
                      styles.selectedText,
                  ]}>
                  All Songs
                </Text>

              </TouchableOpacity>

              {/* QUEUE */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'queue' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Queue')
                }>

                <Image
                  source={ICONS.queue}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'queue' &&
                      styles.selectedText,
                  ]}>
                  Queue
                </Text>

              </TouchableOpacity>

              {/* ALBUMS */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'albums' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Albums')
                }>

                <Image
                  source={ICONS.albums}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'albums' &&
                      styles.selectedText,
                  ]}>
                  Albums
                </Text>

              </TouchableOpacity>

              {/* ARTISTS */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'artists' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Artists')
                }>

                <Image
                  source={ICONS.artists}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'artists' &&
                      styles.selectedText,
                  ]}>
                  Artists
                </Text>

              </TouchableOpacity>

              {/* GENRES */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'genres' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Genres')
                }>

                <Image
                  source={ICONS.genres}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'genres' &&
                      styles.selectedText,
                  ]}>
                  Genres
                </Text>

              </TouchableOpacity>

              {/* PLAYLISTS */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'playlists' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Playlists')
                }>

                <Image
                  source={ICONS.playlists}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'playlists' &&
                      styles.selectedText,
                  ]}>
                  Playlists
                </Text>

              </TouchableOpacity>

              {/* FOLDERS */}

              <TouchableOpacity
                style={[
                  styles.navItem,
                  currentPage === 'folders' &&
                    styles.navItemSelected,
                ]}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Folders')
                }>

                <Image
                  source={ICONS.folders}
                  style={styles.navIcon}
                  resizeMode="contain"
                />

                <Text
                  style={[
                    styles.navText,
                    currentPage === 'folders' &&
                      styles.selectedText,
                  ]}>
                  Folders
                </Text>

              </TouchableOpacity>

            </View>

            {/* ===============================================
                SETTINGS + EQUALIZER
                =============================================== */}

            <View style={styles.bottomNavigation}>

              <View style={styles.bottomDivider} />

              {/* SETTINGS */}

              <TouchableOpacity
                style={styles.bottomItem}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Settings')
                }>

                <Image
                  source={ICONS.settings}
                  style={styles.bottomIcon}
                  resizeMode="contain"
                />

                <Text style={styles.bottomText}>
                  Settings
                </Text>

              </TouchableOpacity>

              {/* EQUALIZER */}

              <TouchableOpacity
                style={styles.bottomItem}
                activeOpacity={0.75}
                onPress={() =>
                  handleDrawerItemPress('Equalizer')
                }>

                <Image
                  source={ICONS.equalizer}
                  style={styles.bottomIcon}
                  resizeMode="contain"
                />

                <Text style={styles.bottomText}>
                  Equalizer
                </Text>

              </TouchableOpacity>

            </View>

          </Animated.View>

        </View>
      )}

    </View>
  );
};

/* =============================================================
   STYLES
   ============================================================= */

const styles = StyleSheet.create({

  /* ===========================================================
     APP
     =========================================================== */

  container: {
    flex: 1,
    backgroundColor: '#050719',
  },

  /* ===========================================================
     SEARCH
     =========================================================== */

  searchOverlay: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,

    zIndex: 50,
    elevation: 50,
  },

  /* ===========================================================
     PLAYER
     =========================================================== */

  playerOverlay: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,

    zIndex: 75,
    elevation: 75,

    backgroundColor: '#090F22',
  },

  /* ===========================================================
     SIDEBAR
     =========================================================== */

  sidebarLayer: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,

    zIndex: 100,
    elevation: 100,
  },

  /* ===========================================================
     BACKGROUND DIMMING
     =========================================================== */

  backgroundOverlay: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,

    backgroundColor: 'rgba(0, 0, 0, 0.48)',
  },

  /* ===========================================================
     OUTSIDE DRAWER
     =========================================================== */

  outsidePress: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
  },

  /* ===========================================================
     DRAWER
     =========================================================== */

  drawer: {
    position: 'absolute',

    top: 0,
    bottom: 0,
    left: 0,

    backgroundColor: '#050719',

    borderRightWidth: 1,
    borderRightColor: '#18213A',

    elevation: 20,

    shadowColor: '#000',

    shadowOffset: {
      width: 5,
      height: 0,
    },

    shadowOpacity: 0.45,
    shadowRadius: 18,
  },

  /* ===========================================================
     DRAWER HEADER
     =========================================================== */

  drawerTop: {
    height: 100,

    paddingTop: 18,
    paddingHorizontal: 16,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  logoBox: {
    width: 44,
    height: 44,

    borderRadius: 10,

    backgroundColor: '#5369F2',

    alignItems: 'center',
    justifyContent: 'center',
  },

  logoText: {
    color: '#FFFFFF',

    fontSize: 25,
    fontWeight: '700',
  },

  closeButton: {
    width: 42,
    height: 42,

    alignItems: 'center',
    justifyContent: 'center',
  },

  closeText: {
    color: '#78839A',

    fontSize: 29,
    fontWeight: '300',
  },

  /* ===========================================================
     NAVIGATION
     =========================================================== */

  navigation: {
    paddingHorizontal: 8,
    paddingTop: 5,
  },

  navItem: {
    height: 52,

    borderRadius: 10,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 16,

    marginBottom: 4,
  },

  navItemSelected: {
    height: 58,

    backgroundColor: '#3548C5',

    marginVertical: 3,
  },

  /* ===========================================================
     PNG ICONS
     =========================================================== */

  navIcon: {
    width: 24,
    height: 24,

    marginRight: 16,
  },

  navText: {
    color: '#B7C0D0',

    fontSize: 16,
    fontWeight: '600',
  },

  selectedText: {
    color: '#FFFFFF',

    fontWeight: '700',
  },

  /* ===========================================================
     SETTINGS / EQUALIZER
     =========================================================== */

  bottomNavigation: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 78,
  },

  bottomDivider: {
    height: 1,

    backgroundColor: '#1B253D',

    marginHorizontal: 2,
    marginBottom: 12,
  },

  bottomItem: {
    height: 48,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 16,

    borderRadius: 9,
  },

  bottomIcon: {
    width: 24,
    height: 24,

    marginRight: 16,
  },

  bottomText: {
    color: '#B7C0D0',

    fontSize: 16,
    fontWeight: '600',
  },

});

export default App;