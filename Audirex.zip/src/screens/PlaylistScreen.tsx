import React from 'react';
import {
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
} from 'react-native';

type PlaylistScreenProps = {
  onBack: () => void;
  onMenuPress: () => void;
  onPlayerPress: () => void;
};

const PlaylistScreen = ({
  onMenuPress,
  onPlayerPress,
}: PlaylistScreenProps) => {
  return (
    <SafeAreaView style={styles.container}>

      {/* =========================================================
          HEADER
          ========================================================= */}

      <View style={styles.header}>

        {/* SIDEBAR BUTTON */}

        <Pressable
          style={styles.menuButton}
          onPress={onMenuPress}>

          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />

        </Pressable>


        {/* TITLE */}

        <Text style={styles.headerTitle}>
          Playlists
        </Text>


        {/* SEARCH */}

        <Pressable style={styles.searchButton}>

          <Text style={styles.searchIcon}>
            ⌕
          </Text>

        </Pressable>

      </View>


      {/* =========================================================
          CONTENT
          ========================================================= */}

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>


        {/* =======================================================
            CREATE PLAYLIST
            ======================================================= */}

        <Pressable style={styles.createButton}>

          <Text style={styles.createPlus}>
            +
          </Text>

          <Text style={styles.createText}>
            Create Playlist
          </Text>

        </Pressable>


        {/* =======================================================
            PLAYLIST COUNT / SORT
            ======================================================= */}

        <View style={styles.listHeader}>

          <Text style={styles.playlistCount}>
            6 playlists
          </Text>

          <Pressable style={styles.sortButton}>

            <Text style={styles.sortIcon}>
              ↕
            </Text>

            <Text style={styles.sortText}>
              Recently added
            </Text>

          </Pressable>

        </View>


        {/* =======================================================
            PLAYLISTS
            ======================================================= */}

        <View style={styles.playlistList}>


          {/* MY PLAYLIST */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                My Playlist

              </Text>

              <Text style={styles.songCount}>
                128 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


          {/* CHILL VIBES */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                Chill Vibes

              </Text>

              <Text style={styles.songCount}>
                56 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


          {/* FOCUS */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                Focus

              </Text>

              <Text style={styles.songCount}>
                42 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


          {/* WORKOUT */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                Workout

              </Text>

              <Text style={styles.songCount}>
                87 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


          {/* ROAD TRIP */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                Road Trip

              </Text>

              <Text style={styles.songCount}>
                72 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


          {/* LOVE SONGS */}

          <Pressable style={styles.playlistItem}>

            <View style={styles.playlistArtwork}>

              <Image
                source={require('../../assets/starlight.jpg')}
                style={styles.artworkImage}
                resizeMode="cover"
              />

            </View>


            <View style={styles.playlistInfo}>

              <Text
                style={styles.playlistName}
                numberOfLines={1}>

                Love Songs

              </Text>

              <Text style={styles.songCount}>
                48 songs
              </Text>

            </View>


            <Pressable style={styles.moreButton}>

              <Text style={styles.moreIcon}>
                ⋮
              </Text>

            </Pressable>

          </Pressable>


        </View>

      </ScrollView>


      {/* =========================================================
          MINI PLAYER

          IMPORTANT:
          Clicking the entire mini player opens PlayerScreen.
          ========================================================= */}

      <Pressable
        style={styles.miniPlayer}
        onPress={onPlayerPress}>

        {/* ARTWORK */}

        <View style={styles.miniArtwork}>

          <Image
            source={require('../../assets/starlight.jpg')}
            style={styles.miniArtworkImage}
            resizeMode="cover"
          />

        </View>


        {/* SONG INFORMATION */}

        <View style={styles.miniInfo}>

          <Text style={styles.miniTitle}>
            Starlight
          </Text>

          <Text style={styles.miniArtist}>
            The Weeknd
          </Text>

        </View>


        {/* PAUSE */}

        <Pressable
          style={styles.miniButton}
          onPress={event => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniPause}>
            Ⅱ
          </Text>

        </Pressable>


        {/* NEXT */}

        <Pressable
          style={styles.miniButton}
          onPress={event => {
            event.stopPropagation();
          }}>

          <Text style={styles.miniNext}>
            ▷|
          </Text>

        </Pressable>

      </Pressable>

    </SafeAreaView>
  );
};


const styles = StyleSheet.create({

  /* =========================================================
     CONTAINER
     ========================================================= */

  container: {
    flex: 1,

    backgroundColor: '#050719',
  },


  /* =========================================================
     HEADER
     ========================================================= */

  header: {
    height: 82,

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 18,

    paddingTop: 12,

    marginBottom: 2,
  },


  menuButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 8,
  },


  menuLine: {
    width: 27,
    height: 2.5,

    backgroundColor: '#C9D0DE',

    marginVertical: 3,

    borderRadius: 2,
  },


  headerTitle: {
    flex: 1,

    color: '#F5F6FA',

    fontSize: 24,

    fontWeight: '700',

    textAlign: 'center',

    marginLeft: 4,
  },


  searchButton: {
    width: 48,
    height: 48,

    alignItems: 'center',
    justifyContent: 'center',
  },


  searchIcon: {
    color: '#D6DCE8',

    fontSize: 31,

    fontWeight: '300',

    marginTop: -4,
  },


  /* =========================================================
     SCROLL
     ========================================================= */

  scrollView: {
    flex: 1,
  },


  content: {
    paddingHorizontal: 12,

    paddingTop: 10,

    paddingBottom: 145,
  },


  /* =========================================================
     CREATE PLAYLIST
     ========================================================= */

  createButton: {
    height: 58,

    borderRadius: 13,

    backgroundColor: '#101C32',

    borderWidth: 1,

    borderColor: '#284265',

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',

    marginBottom: 24,
  },


  createPlus: {
    color: '#F2F4F8',

    fontSize: 28,

    fontWeight: '300',

    marginRight: 10,

    marginTop: -2,
  },


  createText: {
    color: '#F1F3F8',

    fontSize: 16,

    fontWeight: '700',
  },


  /* =========================================================
     LIST HEADER
     ========================================================= */

  listHeader: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',

    marginBottom: 14,

    paddingHorizontal: 2,
  },


  playlistCount: {
    color: '#7D879B',

    fontSize: 12,

    fontWeight: '500',
  },


  sortButton: {
    flexDirection: 'row',

    alignItems: 'center',

    paddingVertical: 5,

    paddingHorizontal: 4,
  },


  sortIcon: {
    color: '#9BA5B8',

    fontSize: 19,

    marginRight: 5,
  },


  sortText: {
    color: '#9BA5B8',

    fontSize: 12,

    fontWeight: '500',
  },


  /* =========================================================
     PLAYLIST LIST
     ========================================================= */

  playlistList: {
    width: '100%',
  },


  playlistItem: {
    width: '100%',

    minHeight: 82,

    flexDirection: 'row',

    alignItems: 'center',

    marginBottom: 8,
  },


  /* =========================================================
     PLAYLIST ARTWORK
     ========================================================= */

  playlistArtwork: {
    width: 70,
    height: 70,

    borderRadius: 11,

    overflow: 'hidden',

    backgroundColor: '#101B31',
  },


  artworkImage: {
    width: '100%',
    height: '100%',
  },


  /* =========================================================
     PLAYLIST INFORMATION
     ========================================================= */

  playlistInfo: {
    flex: 1,

    marginLeft: 14,

    justifyContent: 'center',
  },


  playlistName: {
    color: '#EEF0F5',

    fontSize: 16,

    fontWeight: '700',
  },


  songCount: {
    color: '#7C879C',

    fontSize: 12,

    marginTop: 5,

    fontWeight: '500',
  },


  /* =========================================================
     MORE BUTTON
     ========================================================= */

  moreButton: {
    width: 46,
    height: 60,

    alignItems: 'center',
    justifyContent: 'center',

    marginLeft: 4,
  },


  moreIcon: {
    color: '#AAB3C4',

    fontSize: 26,

    fontWeight: '700',
  },


  /* =========================================================
     MINI PLAYER

     The player is deliberately positioned above the bottom
     edge so it doesn't conflict with the navigation/sidebar
     structure.

     onPress opens PlayerScreen through App.tsx.
     ========================================================= */

  miniPlayer: {
    position: 'absolute',

    left: 10,
    right: 10,

    bottom: 62,

    height: 70,

    borderRadius: 12,

    backgroundColor: '#15233B',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 10,

    elevation: 8,
  },


  miniArtwork: {
    width: 52,
    height: 52,

    borderRadius: 9,

    overflow: 'hidden',

    backgroundColor: '#10284B',
  },


  miniArtworkImage: {
    width: '100%',
    height: '100%',
  },


  miniInfo: {
    flex: 1,

    marginLeft: 12,
  },


  miniTitle: {
    color: '#EEF0F5',

    fontSize: 14,

    fontWeight: '700',
  },


  miniArtist: {
    color: '#808BA0',

    fontSize: 11,

    marginTop: 3,
  },


  miniButton: {
    width: 46,
    height: 58,

    alignItems: 'center',
    justifyContent: 'center',
  },


  miniPause: {
    color: '#F1F3F7',

    fontSize: 22,

    fontWeight: '600',
  },


  miniNext: {
    color: '#F1F3F7',

    fontSize: 22,
  },

});

export default PlaylistScreen;